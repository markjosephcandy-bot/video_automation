# Short 7: Money Is a Promise (who gets new money first) — research 2026-11-04 21:40 IST
Inputs: two ColdFusion transcripts (How is Money Created 2020; Who Controls All of Our Money 2017, Ukrainian subs).

## ColdFusion fact-check
TRUE: banks create deposits when lending (BoE QB 2014 Q1; Bundesbank Apr 2017); 97% of UK money = bank deposits (Dec 2013); Fed reserve requirement to 0% on 26 Mar 2020; Cantillon effect is a real concept; Jekyll Island meeting Nov 1910 real; QE raised asset prices and gains skewed to rich (BoE 12 Jul 2012: top 5% households hold 40% of financial assets outside pensions).
MISLEADING/OUTDATED: 10% reserve x10 money multiplier (BoE: "not an accurate description"); Fed "can't be audited" (GAO audits w/ exclusions + external audit); Fed Act "passed while Congress on vacation" (House 298-60 on 22 Dec, Senate 43-25 on 23 Dec 1913; many senators had left — St Louis Fed).
FALSE: QE invented by BoJ in 1989 (BoJ QE began 2001); $700bn bailout was QE (TARP = Treasury); BoJ owns 80% of stock market (≈80% of Japanese ETFs, ≈6-7% of market; largest holder from 2020-21); only NK/Iran/Cuba lack central banks.
UNSOURCED / FAKE QUOTES: Henry Ford "revolution before tomorrow morning" (Binderup paraphrase, Cong. Record 1937); Lincoln greenback quote (written by Gerry McGeer 1935); "six men owned a quarter of world wealth" (no source).

## India facts for script
- RBI WSS 15 Oct 2026: currency 12.8% of M3, deposits 86.8%.
- RBI Bulletin Sept 2026: deposits created when banks lend or invest (authors' views).
- RBI COVID liquidity measures = 8.7% of GDP announced (RBI speech; ₹17.2 lakh cr offered per Apr 2022), repo cut 115 bps.
- GDP FY2020-21: -7.3% provisional (May 2021; later revised -5.8%). Use "shrank" + cite provisional, or say "contracted".
- Nifty closing low 7,610.25 on 23 Mar 2020; intraday 7,511 on 24 Mar; ~doubled by Feb 2021. Rally causes: Business Standard credits central-bank stimulus esp. Fed; NDTV Profit also cites earnings, FPI inflows.
- World Inequality Lab WP 2024/09 (Bharti, Chancel, Piketty, Somanchi): top 1% wealth 40.1%, income 22.6% (2022-23); wealth highest since 1961 series start; 12.5% in 1980.
- Cantillon: Essai sur la nature du commerce en général, written c.1730, published 1755.
