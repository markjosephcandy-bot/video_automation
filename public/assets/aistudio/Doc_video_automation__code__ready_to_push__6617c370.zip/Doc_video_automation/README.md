# Doc_video_automation (`docvid`)

Automates documentary-style finance and money-history YouTube Shorts, from topic research to a finished,
captioned, loudness-normalised 1080x1920 video. Built for the **EconoFables** channel; rebrand with `brand.yaml`.

```
topic ideas -> grounded research -> fact-check -> script + visual plan -> [human approval]
  -> narration (word timings) -> real images / AI frames / animated infographics / typewriter quotes
  -> per-beat render -> karaoke captions -> final mp4 (<2 min, -14 LUFS) -> youtube.txt -> QA contact sheet
```

| Job | Tool |
|---|---|
| Research, fact-check, script | **Gemini API** with Google Search grounding (`docvid/gemini.py`) |
| AI reconstructions | **Cloudflare Workers AI** text-to-image (`docvid/cloudflare.py`) |
| Real images + licences | Wikimedia Commons API, The Met open access (`docvid/commons.py`) |
| Narration + word timings | edge-tts (free) |
| Typewriter quotes, infographics | Pillow frame rendering -> ffmpeg (`docvid/anim.py`) |
| Render, captions, mix | ffmpeg + libass |

## Setup
```bash
git clone https://github.com/markjosephcandy-bot/Doc_video_automation.git && cd Doc_video_automation
pip install -e .            # or: pip install -r requirements.txt
sudo apt install ffmpeg     # needs libass (subtitles filter)
cp .env.example .env        # add GEMINI_API_KEY, CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN
```
Cloudflare token: dashboard -> My Profile -> API Tokens -> "Workers AI" template. Gemini key: Google AI Studio.

## Make a video
```bash
docvid topics "little-known stories from Indian and world money history" --n 6   # pick one
docvid new episodes/2026-11-10-reis "Alves Reis and the 1925 Banco de Portugal note affair"
#   -> RESEARCH.md, FACTCHECK.md, script.yaml, SCRIPT_REVIEW.md   (READ AND EDIT THESE)
docvid build episodes/2026-11-10-reis
#   -> "<Title> - EconoFables Short.mp4", captions.srt, youtube.txt, contact sheet
docvid render episodes/2026-11-10-reis 4 7 && docvid finish episodes/2026-11-10-reis   # fix single beats
```
Steps can be run one at a time: `research`, `factcheck`, `script`, `tts`, `visuals`, `render`, `finish`, `qa`.
Pin a specific real image with `src:` (URL or path) on a visual; otherwise the first good Commons hit for `query` is used.

## Repo map
- `SKILL.md`: the full playbook (rules, workflow, script.yaml schema). **Start here to regain context.**
- `docs/STYLE_GUIDE.md`, `docs/LESSONS.md`, `docs/EPISODES.md`: look, lessons, topics already covered.
- `prompts/`: the editorial rules and prompt templates sent to Gemini.
- `docvid/`: the pipeline. `examples/money-promise-short/`: a real script, research brief and description.
- `legacy/longform/`: the 16:9 long-form (4-5 min) pipeline and runbook used for earlier episodes.

## Status
- Rendering path (tts -> visuals -> render -> finish) is tested end to end without API keys (local images).
- Gemini and Cloudflare calls follow the public REST docs but still need a first run with real keys.
- Publishing to YouTube is intentionally manual.

Fonts are OFL (Google Fonts). Generated images must be labelled and disclosed; respect each real image's licence.
