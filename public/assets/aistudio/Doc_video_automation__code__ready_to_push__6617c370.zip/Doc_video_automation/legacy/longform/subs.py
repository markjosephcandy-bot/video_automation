import json,yaml,re
tl=json.load(open('timeline.json')); sc=yaml.safe_load(open('script.yaml'))
beats=[b for ch in sc['chapters'] for b in ch['beats']]
def ts_srt(t): h=int(t//3600); m=int(t%3600//60); s=t%60; return f"{h:02d}:{m:02d}:{int(s):02d},{int(round((s%1)*1000)) % 1000:03d}"
def ts_ass(t): h=int(t//3600); m=int(t%3600//60); s=t%60; return f"{h}:{m:02d}:{s:05.2f}"
groups=[]
for i,b in enumerate(beats):
    t0,pre,D=tl['beats'][i]; words=json.load(open(f'tts/{i:03d}.json'))
    # attach punctuation from script text
    toks=b['say'].split(); ti=0; ws=[]
    for st,du,tx in words:
        disp=tx
        # find matching token in script to get punctuation
        for j in range(ti,min(ti+4,len(toks))):
            if re.sub(r'[^\w]','',toks[j]).lower().startswith(re.sub(r'[^\w]','',tx).lower()[:3]):
                disp=toks[j]; ti=j+1; break
        ws.append([t0+pre+st,t0+pre+st+du,disp])
    cur=[]
    for w in ws:
        cur.append(w)
        if len(cur)>=4 or w[2][-1] in '.,?!;:':
            groups.append(cur); cur=[]
    if cur: groups.append(cur)
# srt
out=[]
for k,g in enumerate(groups):
    end=g[-1][1]+0.15
    if k+1<len(groups): end=min(end,groups[k+1][0][0])
    out.append(f"{k+1}\n{ts_srt(g[0][0])} --> {ts_srt(end)}\n{' '.join(w[2] for w in g)}\n")
open('captions.srt','w').write('\n'.join(out))
# ass karaoke-style
hdr="""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Poppins,84,&H00FFFFFF,&H00FFFFFF,&H00181410,&H96000000,1,0,0,0,100,100,0,0,1,5,4,2,80,80,150,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
ev=[]
for k,g in enumerate(groups):
    gend=g[-1][1]+0.25
    if k+1<len(groups): gend=min(gend,groups[k+1][0][0])
    for j,w in enumerate(g):
        s=w[0]; e=g[j+1][0] if j+1<len(g) else gend
        txt=' '.join(('{\\c&H4CB4E9&}'+x[2]+'{\\c&HFFFFFF&}') if jj==j else x[2] for jj,x in enumerate(g))
        ev.append(f"Dialogue: 0,{ts_ass(s)},{ts_ass(e)},Cap,,0,0,0,,{txt}")
open('caps.ass','w').write(hdr+'\n'.join(ev)+'\n')
# transcript + chapters
open('transcript.txt','w').write('\n'.join(b['say'] for b in beats)+'\n')
ch=['0:00 Intro']
for t,n in tl['chapters']:
    ch.append(f"{int(t//60)}:{int(t%60):02d} {n}")
open('chapters.txt','w').write('\n'.join(ch)+'\n')
print(len(groups)); print(open('chapters.txt').read())
