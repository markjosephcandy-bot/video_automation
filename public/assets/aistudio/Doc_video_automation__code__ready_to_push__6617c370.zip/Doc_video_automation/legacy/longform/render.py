import yaml, json, os, subprocess, math, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from concurrent.futures import ThreadPoolExecutor
W,H=1920,1080; FPS=30
import os; F=os.environ.get('DOCVID_FONTS',os.path.join(os.path.dirname(__file__),'../../assets/fonts'))+'/'
def font(n,s,var=None):
    f=ImageFont.truetype(F+n,s)
    if var: 
        try: f.set_variation_by_axes([var])
        except Exception: pass
    return f
BEBAS=lambda s:font('BebasNeue-Regular.ttf',s)
MONT=lambda s,w=500:font('Montserrat[wght].ttf',s,w)
PLAY=lambda s:font('PlayfairDisplay-Italic[wght].ttf',s,400)
POP=lambda s:font('Poppins-Bold.ttf',s)
Y=(233,180,76); WHITE=(255,255,255); BOX=(20,33,61,215)
sc=yaml.safe_load(open('script.yaml'))
beats=[]; chap_starts=[]
ci=0
for ch in sc['chapters']:
    num=None
    if ch['title']: ci+=1; num=ci
    for j,b in enumerate(ch['beats']):
        b=dict(b); b['chapter']=ch['title']; b['cnum']=num; b['first']=(j==0); beats.append(b)
def dur(f): return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f]))
t=0
for i,b in enumerate(beats):
    b['adur']=dur(f'tts/{i:03d}.mp3'); b['pre']=0.6 if (b['first'] and i>0) else 0.15
    b['dur']=b['pre']+b['adur']+0.25; b['t0']=t; t+=b['dur']
    if b['first'] and b['chapter']: chap_starts.append((b['t0'],b['chapter']))
TOTAL=t
def shadow_text(img,xy,txt,f,fill,anchor='la',sh=3,blur=4):
    lay=Image.new('RGBA',img.size,(0,0,0,0)); d=ImageDraw.Draw(lay)
    d.text((xy[0]+sh,xy[1]+sh),txt,font=f,fill=(0,0,0,150),anchor=anchor)
    lay=lay.filter(ImageFilter.GaussianBlur(blur)); img.alpha_composite(lay)
    ImageDraw.Draw(img).text(xy,txt,font=f,fill=fill,anchor=anchor)
def box(img,x0,y0,x1,y1,r=18,bar=False):
    lay=Image.new('RGBA',img.size,(0,0,0,0)); d=ImageDraw.Draw(lay)
    d.rounded_rectangle((x0+6,y0+10,x1+6,y1+10),r,fill=(0,0,0,70)); lay=lay.filter(ImageFilter.GaussianBlur(12))
    img.alpha_composite(lay); d=ImageDraw.Draw(img); d.rounded_rectangle((x0,y0,x1,y1),r,fill=BOX)
    if bar: d.rectangle((x0,y0+6,x0+8,y1-6),fill=Y+(255,))
def wrap(d,txt,f,maxw):
    words=txt.split(); lines=[]; cur=''
    for w in words:
        tt=(cur+' '+w).strip()
        if d.textlength(tt,font=f)<=maxw: cur=tt
        else: lines.append(cur); cur=w
    lines.append(cur); return lines
def fmtnum(v,dec):
    s=f"{v:,.{dec}f}"
    return s
def overlay(i,b):
    img=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(img)
    shadow_text(img,(W-60,48),'ECONOFABLES',BEBAS(46),WHITE,'ra')
    if b['chapter']:
        x=60; f=BEBAS(44); num=f"{b['cnum']:02d}"
        shadow_text(img,(x,48),num,f,Y); x+=d.textlength(num+' ',font=f)+4
        shadow_text(img,(x,48),b['chapter'].upper(),f,WHITE)
    s=b.get('show')
    if not s: return img
    ty=s['type']
    if ty=='stat':
        v=s['value']; dec=s.get('decimals',0)
        if v>=1e9 and not s.get('suffix'):
            num=fmtnum(v/1e9,0 if v%1e9==0 else 1); suf=' BILLION'
        else: num=fmtnum(v,dec); suf=s.get('suffix','').upper()
        pre=s.get('prefix','')
        fb=BEBAS(170); fs=BEBAS(76); fp=BEBAS(120); fl=MONT(36,500)
        pw=d.textlength(pre,font=fp if pre in('₹','$','-') else fs); nw=d.textlength(num,font=fb); sw=d.textlength(suf,font=fs)
        lw=d.textlength(s['label'],font=fl); inner=max(pw+nw+sw+10,min(lw,1300))
        lab=wrap(d,s['label'],fl,1300)
        bw=inner+120; bh=230+len(lab)*48; x0=(W-bw)/2; y0=250
        box(img,x0,y0,x0+bw,y0+bh,22); d=ImageDraw.Draw(img)
        x=(W-(pw+nw+sw+10))/2; base=y0+200
        pf=fp if pre in('₹','$','-') else fs
        d.text((x,base),pre,font=pf,fill=WHITE,anchor='ls'); x+=pw+4
        d.text((x,base),num,font=fb,fill=Y,anchor='ls'); x+=nw+6
        d.text((x,base),suf,font=fs,fill=WHITE,anchor='ls')
        for k,l in enumerate(lab): d.text((W/2,base+48+k*48),l,font=fl,fill=(235,228,215),anchor='ms')
    elif ty=='headline':
        f=BEBAS(150); words=s['text'].upper().split(); em=[e.upper() for e in s.get('emphasis',[])]
        emw=set(' '.join(em).split())
        lines=wrap(d,s['text'].upper(),f,1600)
        lay=Image.new('RGBA',(W,H),(0,0,0,0)); ld=ImageDraw.Draw(lay)
        ld.ellipse((200,300,1720,800),fill=(10,18,36,120)); lay=lay.filter(ImageFilter.GaussianBlur(90)); img.alpha_composite(lay)
        y=H/2-len(lines)*150/2+120
        for l in lines:
            ww=d.textlength(l,font=f); x=(W-ww)/2
            for w in l.split():
                col=Y if w.strip('.,') in emw else WHITE
                shadow_text(img,(x,y),w,f,col,'ls',5,8); x+=d.textlength(w+' ',font=f)
            y+=150
    elif ty=='term':
        fw=BEBAS(84); fm=MONT(36,500); lines=wrap(d,s['meaning'],fm,640)
        x0,y0=60,130; bw=max(760,d.textlength(s['word'].upper(),font=fw)+100); bh=150+len(lines)*50
        box(img,x0,y0,x0+bw,y0+bh,16,True); d=ImageDraw.Draw(img)
        d.text((x0+50,y0+105),s['word'].upper(),font=fw,fill=Y,anchor='ls')
        for k,l in enumerate(lines): d.text((x0+50,y0+165+k*50),l,font=fm,fill=WHITE,anchor='ls')
    elif ty=='quote':
        fq=PLAY(54); fb=MONT(30,600); lines=wrap(d,'“'+s['text']+'”',fq,1250)
        bw=1400; bh=120+len(lines)*72+60; x0=(W-bw)/2; y0=280
        box(img,x0,y0,x0+bw,y0+bh,16,True); d=ImageDraw.Draw(img)
        for k,l in enumerate(lines): d.text((x0+80,y0+100+k*72),l,font=fq,fill=(248,240,225),anchor='ls')
        d.text((x0+80,y0+bh-45),'— '+s['by'],font=fb,fill=Y,anchor='ls')
    elif ty=='list':
        ft=MONT(28,700); fi=MONT(38,600); items=s['items']
        bw=max(d.textlength(it,font=fi) for it in items)+170; bw=max(bw,560); bh=120+len(items)*62
        x0=W-60-bw; y0=380
        box(img,x0,y0,x0+bw,y0+bh,16); d=ImageDraw.Draw(img)
        tt=' '.join(s['title'].upper())
        d.text((x0+50,y0+70),s['title'].upper(),font=ft,fill=Y,anchor='ls')
        for k,it in enumerate(items):
            yy=y0+130+k*62; d.rectangle((x0+50,yy-22,x0+64,yy-8),fill=Y)
            d.text((x0+85,yy),it,font=fi,fill=WHITE,anchor='ls')
    elif ty=='date':
        f=BEBAS(150); fs=MONT(34,500)
        shadow_text(img,(70,640),s['text'].upper(),f,Y,'ls',4,8)
        d=ImageDraw.Draw(img); d.rectangle((72,665,72+380,670),fill=Y)
        shadow_text(img,(72,720),s['sub'],fs,WHITE,'ls',2,4)
    elif ty=='title':
        ft=MONT(30,700); fb=BEBAS(160)
        lay=Image.new('RGBA',(W,H),(0,0,0,0)); ld=ImageDraw.Draw(lay)
        ld.ellipse((150,150,1770,650),fill=(10,18,36,120)); lay=lay.filter(ImageFilter.GaussianBlur(100)); img.alpha_composite(lay)
        shadow_text(img,(W/2,250),'E C O N O F A B L E S',ft,Y,'ms',2,3)
        lines=wrap(d,sc['title'].upper(),fb,1650)
        for k,l in enumerate(lines): shadow_text(img,(W/2,400+k*150),l,fb,WHITE,'ms',5,8)
        d=ImageDraw.Draw(img); yy=400+(len(lines)-1)*150+45; d.rectangle((W/2-160,yy,W/2+160,yy+5),fill=Y)
    elif ty=='chart':
        fl=MONT(26,600); ft=BEBAS(58); fv=BEBAS(48); fn=MONT(22,400)
        bw,bh=1000,620; x0=W-60-bw; y0=200
        box(img,x0,y0,x0+bw,y0+bh,16); d=ImageDraw.Draw(img)
        d.text((x0+bw/2,y0+80),s['title'].upper(),font=ft,fill=WHITE,anchor='ms')
        d.text((x0+bw/2,y0+118),s.get('note',''),font=fn,fill=(220,210,195),anchor='ms')
        vals=s['values']; mx=max(vals); n=len(vals); gw=(bw-140)/n; base=y0+bh-80; top=y0+190
        for k,(lb,v) in enumerate(zip(s['labels'],vals)):
            bx=x0+70+k*gw+gw*0.18; bwid=gw*0.64; hh=(base-top)*v/mx
            col=Y if v==mx else (235,225,205)
            d.rectangle((bx,base-hh,bx+bwid,base),fill=col)
            d.text((bx+bwid/2,base-hh-12),f"{v:,}",font=fv,fill=col,anchor='ms')
            d.text((bx+bwid/2,base+40),lb,font=fl,fill=WHITE,anchor='ms')
    elif ty=='cta':
        f=POP(54); txt='SUBSCRIBE'; tw=d.textlength(txt,font=f)
        bw=tw+170; bh=110; x0=(W-bw)/2; y0=600
        lay=Image.new('RGBA',(W,H),(0,0,0,0)); ld=ImageDraw.Draw(lay)
        ld.rounded_rectangle((x0+6,y0+12,x0+bw+6,y0+bh+12),55,fill=(0,0,0,110)); lay=lay.filter(ImageFilter.GaussianBlur(14)); img.alpha_composite(lay)
        d=ImageDraw.Draw(img); d.rounded_rectangle((x0,y0,x0+bw,y0+bh),55,fill=(225,30,30,255))
        cx,cy=x0+70,y0+bh/2; d.ellipse((cx-24,cy-24,cx+24,cy+24),fill=WHITE); d.polygon([(cx-8,cy-12),(cx-8,cy+12),(cx+12,cy)],fill=(225,30,30))
        d.text((x0+115,y0+bh/2),txt,font=f,fill=WHITE,anchor='lm')
    return img
os.makedirs('ov',exist_ok=True); os.makedirs('seg',exist_ok=True)
def render(i):
    b=beats[i]; ov=f'ov/{i:03d}.png'; overlay(i,b).save(ov)
    imgs=b['images']; n=len(imgs); D=b['dur']; sd=D/n
    ins=[]; fc=[]
    for k,im in enumerate(imgs):
        fr=int(round(sd*FPS))+1
        ins+=['-i',f'images/{im}']
        mode=(i+k)%4
        z=f"1.0+0.07*on/{fr}" if mode!=1 else f"1.07-0.07*on/{fr}"
        if mode==2: x=f"(iw-iw/zoom)*on/{fr}"; y="(ih-ih/zoom)/2"
        elif mode==3: x=f"(iw-iw/zoom)*(1-on/{fr})"; y="(ih-ih/zoom)/2"
        else: x="(iw-iw/zoom)/2"; y="(ih-ih/zoom)/2"
        fc.append(f"[{k}:v]scale=3840:2160,setsar=1,zoompan=z='{z}':x='{x}':y='{y}':d={fr}:s=1920x1080:fps={FPS},trim=0:{sd:.3f},setpts=PTS-STARTPTS[v{k}]")
    ins+=['-loop','1','-t',f'{D:.3f}','-i',ov,'-i',f'tts/{i:03d}.mp3']
    cat=''.join(f'[v{k}]' for k in range(n))+f'concat=n={n}:v=1:a=0,format=yuv420p[bg]'
    fade_st=max(0,b['pre']+0.15)
    fc.append(cat); fc.append(f"[{n}:v]format=rgba,fade=t=in:st={fade_st:.2f}:d=0.35:alpha=1[o]")
    fc.append(f"[bg][o]overlay=0:0:shortest=1,format=yuv420p[v]")
    fc.append(f"[{n+1}:a]adelay={int(b['pre']*1000)}|{int(b['pre']*1000)},apad,atrim=0:{D:.3f},aformat=sample_rates=48000:channel_layouts=stereo[a]")
    cmd=['ffmpeg','-y','-v','error']+ins+['-filter_complex',';'.join(fc),'-map','[v]','-map','[a]','-t',f'{D:.3f}','-r',str(FPS),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000',f'seg/{i:03d}.mp4']
    r=subprocess.run(cmd,capture_output=True,text=True)
    if r.returncode: print('FAIL',i,r.stderr[-800:])
    return i
if __name__=='__main__':
    json.dump({'total':TOTAL,'chapters':chap_starts,'beats':[[b['t0'],b['pre'],b['dur']] for b in beats]},open('timeline.json','w'))
    sel=[int(a) for a in sys.argv[1:]] or list(range(len(beats)))
    with ThreadPoolExecutor(2) as ex: list(ex.map(render,sel))
    print('done',len(sel),'total',TOTAL)
