import asyncio, os, json, yaml, edge_tts
for k in list(os.environ):
    if 'proxy' in k.lower(): os.environ.pop(k)
sc=yaml.safe_load(open('script.yaml'))
beats=[b for ch in sc['chapters'] for b in ch['beats']]
sem=asyncio.Semaphore(6)
async def one(i,t):
    out=f'tts/{i:03d}.mp3'
    if os.path.exists(out) and os.path.getsize(out)>1000 and os.path.exists(f'tts/{i:03d}.json'): return
    async with sem:
        for a in range(3):
            try:
                c=edge_tts.Communicate(t,'en-US-AndrewMultilingualNeural',rate='+4%',pitch='-2Hz',boundary='WordBoundary')
                words=[]
                with open(out,'wb') as f:
                    async for ch in c.stream():
                        if ch['type']=='audio': f.write(ch['data'])
                        elif ch['type']=='WordBoundary': words.append([ch['offset']/1e7,ch['duration']/1e7,ch['text']])
                json.dump(words,open(f'tts/{i:03d}.json','w')); return
            except Exception as e: print('retry',i,e); await asyncio.sleep(2)
async def main(): await asyncio.gather(*[one(i,b['say']) for i,b in enumerate(beats)])
asyncio.run(main()); print(len(beats))
