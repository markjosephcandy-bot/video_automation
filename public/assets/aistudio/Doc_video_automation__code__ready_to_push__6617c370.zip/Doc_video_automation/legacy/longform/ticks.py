# makes ticks.png: progress-bar track + chapter tick marks (run in episode dir after render.py)
import json; from PIL import Image, ImageDraw
tl=json.load(open('timeline.json')); W,H=1920,1080; T=tl['total']
im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
d.rectangle((0,1072,W,H),fill=(0,0,0,110))
for t,_ in tl['chapters']:
    x=int(W*t/T); d.rectangle((x-2,1070,x+2,H),fill=(255,255,255,230))
im.save('ticks.png'); print('ticks',len(tl['chapters']))
