# usage: python3 thumbnail.py "LINE ONE" "LINE TWO WITH" "ACCENTWORD" "SUBTITLE"
# needs thumb_bg.png (16:9 watercolor art, subject on the RIGHT, calm left side) in episode dir
import sys; from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os; F=os.environ.get('DOCVID_FONTS',os.path.join(os.path.dirname(__file__),'../../assets/fonts'))+'/'; W,H=1280,720; DARK=(20,33,61); Y=(233,180,76)
l1,l2,acc,sub=sys.argv[1:5]
bg=Image.open('thumb_bg.png').convert('RGBA'); s=max(W/bg.width,H/bg.height)
bg=bg.resize((round(bg.width*s),round(bg.height*s))); bg=bg.crop(((bg.width-W)//2,(bg.height-H)//2,(bg.width-W)//2+W,(bg.height-H)//2+H))
fb=ImageFont.truetype(F+'Poppins-ExtraBold.ttf',118); fs=ImageFont.truetype(F+'Poppins-ExtraBold.ttf',52)
d=ImageDraw.Draw(bg)
def t(x,y,txt,f,fill,sw=8,sf=(255,255,255)): d.text((x,y),txt,font=f,fill=fill,stroke_width=sw,stroke_fill=sf)
t(40,40,l1.upper(),fb,DARK); t(40,185,l2.upper(),fb,DARK)
x=40+d.textlength(l2.upper()+' ',font=fb); t(x,185,acc.upper(),fb,Y,8,DARK)
t(44,370,sub.upper(),fs,(255,255,255),6,DARK)
bg.convert('RGB').save('thumbnail.jpg',quality=92); print('thumbnail.jpg')
