# EconoFables — episode runbook (one full episode per run)

Channel: EconoFables (@EconoFables), a NEW channel covering finance, economy, banking, markets and money history. Tagline: 'Every rupee has a story.' English, ~4–5 min explainers that hook on a finance story trending TODAY and tell the true historical story behind it, with an Indian-audience angle and a "what it means for your money" ending. Education only, never buy/sell advice.
Logo/brand: navy #14213D, gold #E9B44C, cream #F6EEDC; user's chosen logo/banner/watermark in assets/brand (user_*.webp). Outro/CTA line: 'subscribe to EconoFables. Every rupee has a story.' Never say 'The Coin Teller' anywhere (script, youtube.txt, tags).
Reference episodes (match quality): <workdir>/ref (When India Pawned Its Gold) and <workdir>/ep2 (When the Internet Bubble Burst). Examples here: script_example.yaml, research_example.md, youtube_example.txt.

## 0. Setup
- `pip install -q edge-tts pyyaml pillow` (edge_tts may be missing after sandbox resets). ffmpeg must be present.
- Episode dir: `<workdir>/episodes/YYYY-MM-DD-am` or `-pm` (IST date). Copy pipeline scripts in: `cp <workdir>/pipeline/*.py <workdir>/pipeline/final.sh .` and `mkdir images tts`.
- Read `<workdir>/episodes/LOG.md` (create if missing): never repeat a topic or historical story already covered (also: Al-Ghazali & inflation; India pawning gold 1991; dot-com bubble/Ketan Parekh).

## 1. Research (detailed)
- web_search the last 24–48 h of finance news (global markets, India: Sensex/Nifty, RBI, rupee, gold/silver, IPOs, crypto, budgets, big company moves). Pick the story with most search interest that has a strong, TRUE historical parallel.
- Fetch (web_fetch) at least 5–8 sources: 2+ current news reports and 3+ for the history (reputable news archives, Wikipedia + its citations, RBI/SEBI/official data). Verify every number, date and quote you will say.
- Write research.md: the hook story, timeline, fact sheet (each fact with source URL + date), angle for Indian viewers, and what NOT to claim.

## 2. Script (script.yaml, same schema as script_example.yaml)
- ~32–40 beats, 600–750 words, 6–7 chapters: cold-open hook from today's news (first 30 s), the history as a story with characters and tension, the turning point, an India angle, "X years later", "Your Money Today" lessons, CTA beat (`show: {type: cta}`).
- Short spoken sentences, numbers written as words in `say`, conversational, curiosity loops ("but here's the twist").
- About half the beats get an on-screen card via `show`: types supported by render.py: stat {value,decimals,prefix,suffix,label}, headline {text,emphasis[]}, term {word,meaning}, quote {text,by}, list {title,items[]}, date {text,sub}, chart {title,note,labels[],values[]}, title (beat 4 of intro), cta (last beat).
- Each beat lists 1 image (`images: [eNN_01.png]`), ~30–34 unique images total; a long beat may use 2.
- Fill title, description, tags in the yaml.

## 3. Images
- generate_image, aspect_ratio 16:9, one per image file, saved into `images/`. Style prefix for EVERY prompt: "Hand-drawn watercolor and ink storybook illustration, warm cream paper texture, soft golden #E9B44C and deep navy-blue washes, fine brown ink linework, cinematic composition, gentle light, consistent style. No text, no letters, no numbers, no logos, no watermark." Then the scene. Keep people generic (no real-person likeness claims); avoid any visible words. Leave room where cards appear (upper-center for stat/quote, left for term, right for list/chart).
- Look at a contact sheet (ffmpeg tile) and regenerate any image with garbled text or off-style.
- Also generate `thumb_bg.png` (16:9, bold single subject on the RIGHT half, calm light left side, same style, no text).

## 4. Voice, render, captions
In the episode dir, in this order:
1. `python3 tts.py` (voice en-US-AndrewMultilingualNeural, +4%, -2Hz; writes tts/NNN.mp3 + word timings).
2. `python3 render.py` (writes timeline.json, seg/*.mp4; long-running — use background shell and wait). Re-run with beat indices for any FAIL.
3. `python3 subs.py` (captions.srt, caps.ass word-highlight captions, transcript.txt, chapters.txt).
4. `python3 ticks.py`
5. `bash final.sh` → "<Title> - EconoFables.mp4" (1920×1080, 30 fps).
6. QA: extract ~6 frames (ffmpeg) and look at them: captions readable, cards not overflowing, no garbled image text. Check audio length ≈ video length. Fix and re-render bad beats.

## 5. Thumbnail
`python3 thumbnail.py "LINE ONE" "LINE TWO" "ACCENT" "SUBTITLE"` → thumbnail.jpg (1280×720). 2–5 punchy words per line, accent word gold. Look at it; fix overflow.

## 6. youtube.txt (same sections as youtube_example.txt)
TITLE (≤70 chars, curiosity + keyword), 2 ALTERNATIVE TITLES, DESCRIPTION (hook paragraph with keywords), CHAPTERS (from chapters.txt), SOURCES (title, outlet, date, URL), subscribe line, disclaimer (education not financial advice; AI voice; AI images), TAGS (15–20), HASHTAGS (3), PINNED COMMENT, THUMBNAIL TEXT, UPLOAD SETTINGS (Education, not made for kids, altered/synthetic content: Yes, English, upload captions.srt, thumbnail.jpg). Also write metadata.md (title, topic, duration, sources summary).

## 7. Upload to Google Drive
- Create folder in My Drive named `YYYY-MM-DD AM - <Title>` (or PM), upload: the mp4, thumbnail.jpg, captions.srt, youtube.txt, chapters.txt, metadata.md, research.md, transcript.txt, script.yaml, and an `images` subfolder with all images. Verify by listing the folder.
- Do NOT upload to YouTube or post publicly.

## 8. Wrap up
- Append to <workdir>/episodes/LOG.md: date, slot, title, topic, historical story, Drive folder link.
- Reply to the user: one short message with the episode title, the news hook in a sentence, duration, and the Drive folder link; attach thumbnail.jpg via display_file.
- If something blocks (Drive disconnected, image generation failing), still finish what you can and say plainly what is missing.
