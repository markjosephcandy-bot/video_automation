# run inside the episode dir after tts.py, render.py, subs.py, ticks.py
set -e
FONTS=${DOCVID_FONTS:-$(dirname "$0")/../../assets/fonts}
NAME="$(python3 -c "import yaml;print(yaml.safe_load(open('script.yaml'))['title'])") - EconoFables.mp4"
T=$(python3 -c "import json;print(json.load(open('timeline.json'))['total'])")
ls seg/*.mp4 | sed "s/.*/file '&'/" > list.txt
ffmpeg -y -v error -f concat -safe 0 -i list.txt -c copy /tmp/ct_cat.mp4
ffmpeg -y -v error -f lavfi -i "sine=f=130.81:d=$T" -f lavfi -i "sine=f=196:d=$T" -f lavfi -i "sine=f=261.63:d=$T" -f lavfi -i "sine=f=329.63:d=$T" -filter_complex "[0][1][2][3]amix=inputs=4,lowpass=f=1200,tremolo=f=0.2:d=0.4,aecho=0.8:0.7:600:0.35,volume=0.5,afade=t=in:d=3,afade=t=out:st=$(python3 -c "print($T-4)"):d=4,aformat=channel_layouts=stereo:sample_rates=48000" /tmp/ct_bed.wav
ffmpeg -y -v error -i /tmp/ct_cat.mp4 -i ticks.png -i /tmp/ct_bed.wav -filter_complex "[0:v][1:v]overlay=0:0,drawbox=x=0:y=1072:w='iw*t/$T':h=8:color=0xE9B44C@1:t=fill,subtitles=caps.ass:fontsdir=$FONTS[v];[0:a]loudnorm=I=-16:TP=-1.5:LRA=11[n];[2:a]volume=0.08[b];[n][b]amix=inputs=2:duration=first:normalize=0[a]" -map "[v]" -map "[a]" -c:v libx264 -preset veryfast -crf 20 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart /tmp/ct_final.mp4
cp /tmp/ct_final.mp4 "$NAME"
ffprobe -v error -show_entries format=duration,size -show_entries stream=codec_type,width,height -of default=nw=1 "$NAME"
