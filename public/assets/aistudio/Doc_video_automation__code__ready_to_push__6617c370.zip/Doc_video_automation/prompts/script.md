Write a {format} script from the research brief below. Follow every editorial rule.

Return JSON with:
- title (no question mark, <= 70 chars)
- beats: list of 12-20 beats. Each beat:
  - say: the narration (full spoken sentences; the last beat is exactly the CTA line "{cta}")
  - heading: short on-screen heading (2-6 words, no question mark) or "" for none
  - emphasis: list of 1-2 words from the heading to colour gold
  - visuals: 1-3 visual specs that show what this line says, each one of:
      {{"kind":"real","query":"Wikimedia Commons search terms","what":"what the image shows"}}
      {{"kind":"ai","prompt":"bright, period-accurate reconstruction prompt, vertical 9:16, no text","what":"..."}}
      {{"kind":"typewriter","header":"SOURCE NAME","sub":"publication, date","quote":"exact quote","highlight":"key phrase inside quote"}}
      {{"kind":"counter","title":"...","value":8.7,"decimals":1,"suffix":"%","label":"...","sub":"...","source":"Source: ..."}}
      {{"kind":"donut","title":"...","values":[["label",86.8],["label",12.8]],"center_label":"...","source":"Source: ..."}}
      {{"kind":"bars","title":"...","bars":[["1980",12.5],["2022-23",40.1]],"suffix":"%","source":"Source: ...","note":""}}
      {{"kind":"line","title":"...","points":[["Jan 2020",12200],["Mar 2020",7610]],"marks":[[1,"7,610 · 23 Mar 2020"]],"source":"Source: ..."}}
      {{"kind":"timeline","items":[["c.1780 BCE","Clay tablets record grain loans"],["1971","Gold link cut"]],"footer":"..."}}
      {{"kind":"ladder","rungs":["Step one","Step two","Step three"],"note":"...","sub":"Simplified illustration"}}
  - facts: list of fact-bank numbers this beat relies on
- description: YouTube description (hook paragraph, sources with URLs, AI disclosure)
- tags: comma-separated, under 450 characters

Rules: a typewriter beat must quote the source verbatim from the brief. Use at most {max_ai} "ai" visuals.
Spoken numbers must equal on-screen numbers.

RESEARCH BRIEF:
{brief}
