Suggest {n} rare, little-known story ideas for the niche below. Use Google Search to check each one is real
and has primary sources. Avoid the obvious stories everyone has covered{avoid}.

NICHE: {niche}

For each idea give: a working title (no question mark), the one-line hook naming the subject and stakes,
why it is rare, 2-3 key verifiable facts with source URLs, and what real images likely exist.
