Research the topic below for a {format} video. Use Google Search. Prefer primary sources.

TOPIC: {topic}
ANGLE / NOTES: {notes}

Write a research brief in markdown with these sections:
1. One-paragraph story summary and why it matters to an Indian viewer today.
2. Fact bank: a numbered list. Each fact = the claim, its exact number/date/quote, the source title and URL,
   and a strength tag [strong | needs nuance | weak].
3. Conflicts between sources (what differs, which sources) and how to handle each on air.
4. Quotes usable verbatim (exact wording, page/section, URL).
5. Visual leads: real images that exist (museum objects, documents, photos, paintings) with where to find them,
   and moments that need an artist's impression.
6. Claims to avoid (common myths or unverifiable figures).
