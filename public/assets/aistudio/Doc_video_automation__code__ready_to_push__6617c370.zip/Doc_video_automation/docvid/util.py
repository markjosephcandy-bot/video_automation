def beats(sc):
    """Flatten script.yaml chapters -> list of beats."""
    return [b for ch in sc["chapters"] for b in ch["beats"]]
