"""Narration with edge-tts (free) + word timings. Retries: edge-tts sometimes returns 'No audio was received'."""
import asyncio, json, os, pathlib, yaml
from . import config
from .util import beats as all_beats

def run(ep_dir, passes=3):
    ep = pathlib.Path(ep_dir); (ep / "tts").mkdir(exist_ok=True)
    import edge_tts
    for k in list(os.environ):
        if "proxy" in k.lower(): os.environ.pop(k)
    bs = all_beats(yaml.safe_load((ep / "script.yaml").read_text()))
    sem = asyncio.Semaphore(6)
    async def one(i, text):
        mp3, js = ep / f"tts/{i:03d}.mp3", ep / f"tts/{i:03d}.json"
        if mp3.exists() and mp3.stat().st_size > 1000 and js.exists(): return
        async with sem:
            for _ in range(3):
                try:
                    c = edge_tts.Communicate(text, config.VOICE, rate=config.VOICE_RATE, pitch=config.VOICE_PITCH, boundary="WordBoundary")
                    words = []
                    with open(mp3, "wb") as f:
                        async for ch in c.stream():
                            if ch["type"] == "audio": f.write(ch["data"])
                            elif ch["type"] == "WordBoundary": words.append([ch["offset"] / 1e7, ch["duration"] / 1e7, ch["text"]])
                    js.write_text(json.dumps(words)); return
                except Exception as e:
                    print("tts retry", i, e); await asyncio.sleep(2)
    for _ in range(passes):
        asyncio.run(_gather(one, bs))
        if all((ep / f"tts/{i:03d}.json").exists() for i in range(len(bs))): break
    missing = [i for i in range(len(bs)) if not (ep / f"tts/{i:03d}.json").exists()]
    if missing: raise SystemExit(f"TTS failed for beats {missing}; rerun `docvid tts`")
    words = sum(len(b["say"].split()) for b in bs); print(f"tts ok: {len(bs)} beats, {words} words")

def _gather(one, bs):
    async def main():
        await asyncio.gather(*[one(i, b["say"]) for i, b in enumerate(bs)])
    return main()
