"""Resolve every beat's visual specs into files in images/: real images (Wikimedia/Met/local),
Cloudflare AI reconstructions, and animated infographics. Writes credits.json for the description."""
import json, pathlib, yaml, re
from . import stills, anim, commons, cloudflare
from .util import beats as all_beats
from .timing import slots

AI_STYLE = ("Vertical 9:16, bright, richly detailed, period-accurate historical reconstruction, documentary realism, "
            "warm natural light, vivid but natural colours, not dark, not grey, cinematic history documentary still, "
            "no readable text, no watermark, no anachronisms. Scene: ")

def build(ep_dir, only=None, force=False):
    ep = pathlib.Path(ep_dir); (ep / "images").mkdir(exist_ok=True); (ep / "img").mkdir(exist_ok=True)
    sc = yaml.safe_load((ep / "script.yaml").read_text()); bs = all_beats(sc)
    tl = json.loads((ep / "timeline.json").read_text())
    credits = json.loads((ep / "credits.json").read_text()) if (ep / "credits.json").exists() else {}
    for i, b in enumerate(bs):
        if only and i not in only: continue
        for v, s0, sd in slots(b, tl["beats"][i]["dur"]):
            out = ep / "images" / v["file"]
            if out.exists() and not force: continue
            kind = v.get("kind", "real"); print(f"beat {i}: {kind} -> {v['file']}")
            if kind in anim.KINDS:
                if kind == "typewriter":
                    anim.typewriter(v, sd + 0.5, str(out), t_start=0.4, t_end=max(1.5, sd - 1.4))
                else:
                    anim.KINDS[kind](v, sd + 0.5, str(out))
            elif kind == "ai":
                raw = ep / "img" / (pathlib.Path(v["file"]).stem + "_raw.png")
                if not raw.exists():
                    cloudflare.generate_image(AI_STYLE + v["prompt"], str(raw))
                stills.refine(str(raw), str(out), v.get("tag") or f"{v.get('what','')} · artist's impression (AI-generated)".strip(" ·"), b=1.0, c=1.05, col=1.05)
                credits[v["file"]] = {"ai": True, "what": v.get("what", "")}
            elif kind == "cta":
                stills.gradient_bg(str(out))
            else:   # real
                src, cred = _real_source(v, ep)
                if not src:
                    print("  !! no real image found; add `src:` (path or URL) to this visual"); continue
                txt = v.get("tag") or cred.get("tag", "")
                fit = v.get("fit", "refine")
                if fit == "framed": stills.framed(src, str(out), txt)
                elif fit == "paper": stills.onpaper(src, str(out), txt)
                elif fit == "pan": stills.panclip(src, str(out).replace(".png", ".mp4"), txt, dur=sd + 0.5); v["file"] = v["file"].replace(".png", ".mp4")
                else: stills.refine(src, str(out), txt, v.get("cx", 0.5), v.get("cy", 0.5))
                credits[v["file"]] = cred
    (ep / "script.yaml").write_text(yaml.safe_dump(sc, allow_unicode=True, sort_keys=False, width=1000))
    (ep / "credits.json").write_text(json.dumps(credits, indent=1, ensure_ascii=False))

def _real_source(v, ep):
    import requests
    if v.get("src"):
        s = v["src"]
        if s.startswith("http"):
            p = ep / "img" / re.sub(r"[^\w.]+", "_", s.split("/")[-1])[-80:]
            if not p.exists():
                p.write_bytes(requests.get(s, headers=commons.HDR, timeout=120).content)
            s = str(p)
        return s, {"tag": v.get("tag", ""), "credit": v.get("credit", "")}
    q = v.get("query") or v.get("what")
    hits = [h for h in commons.search(q) if (h.get("width") or 0) >= 700]
    if not hits:
        return None, {}
    h = hits[0]; p = ep / "img" / re.sub(r"[^\w.]+", "_", h["title"].replace("File:", ""))[-80:]
    if not p.exists(): commons.download(h, str(p))
    who = h.get("artist") or "Wikimedia Commons"
    return str(p), {"tag": f"{v.get('what') or h['title'][5:]} · {who}, {h.get('licence','')}"[:150],
                    "credit": commons.credit(h), "page": h.get("page")}
