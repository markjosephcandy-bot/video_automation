"""Turn any source image into a full 9:16 frame (no empty bands) with a small source tag."""
import subprocess
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance as E
from .config import W, H, MONT

def cover(im, cx=0.5, cy=0.5):
    s = max(W / im.width, H / im.height)
    im = im.resize((round(im.width * s) + 1, round(im.height * s) + 1), Image.LANCZOS)
    x = int((im.width - W) * cx); y = int((im.height - H) * cy)
    return im.crop((x, y, x + W, y + H))

def tag(img, txt, y=None):
    """Source credit pill, bottom-left, above the caption-free zone."""
    if not txt or not txt.strip(): return img
    d = ImageDraw.Draw(img); f = MONT(24, 500); y = y or H - 410
    lines = [txt] if d.textlength(txt, font=f) < 980 or " · " not in txt else [txt[:txt.rfind(" · ")], txt[txt.rfind(" · ") + 3:]]
    for k, l in enumerate(lines):
        tw = d.textlength(l, font=f); yy = y + k * 40
        d.rounded_rectangle((26, yy - 7, 40 + tw + 14, yy + 33), 10, fill=(0, 0, 0, 140))
        d.text((40, yy), l, font=f, fill=(246, 238, 220))
    return img

def refine(src, out, txt, cx=0.5, cy=0.5, b=1.08, c=1.12, col=1.15):
    """Full-bleed photo, gently brightened ('refined') so nothing looks dull."""
    r = cover(Image.open(src).convert("RGB"), cx, cy)
    r = E.Brightness(r).enhance(b); r = E.Contrast(r).enhance(c); r = E.Color(r).enhance(col); r = E.Sharpness(r).enhance(1.25)
    tag(r.convert("RGBA"), txt).convert("RGB").save(out)

def framed(src, out, txt, width=1000, cy=0.46, crop=None, maxh=1300):
    """Small/odd-shaped originals: sharp copy over a blurred fill of itself."""
    im = Image.open(src).convert("RGB")
    if crop: im = im.crop(crop)
    bg = E.Brightness(cover(im).filter(ImageFilter.GaussianBlur(40))).enhance(0.9).convert("RGBA")
    s = im.resize((width, round(im.height * width / im.width)), Image.LANCZOS)
    if s.height > maxh: s = im.resize((round(im.width * maxh / im.height), maxh), Image.LANCZOS)
    s = E.Sharpness(s).enhance(1.3).convert("RGBA")
    x = (W - s.width) // 2; y = int(H * cy - s.height / 2)
    sh = Image.new("RGBA", bg.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rectangle((x + 12, y + 18, x + s.width + 12, y + s.height + 18), fill=(0, 0, 0, 150))
    bg.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16))); bg.alpha_composite(s, (x, y))
    tag(bg, txt).convert("RGB").save(out)

def onpaper(src, out, txt, width=860, cy=0.55):
    """Vox-style: object photo as a white-bordered print on paper texture."""
    from .anim import paper_bg
    bg = paper_bg().convert("RGBA"); im = Image.open(src).convert("RGB")
    im = E.Contrast(E.Brightness(im).enhance(1.2)).enhance(1.15)
    s = im.resize((width, round(im.height * width / im.width)), Image.LANCZOS).convert("RGBA")
    if s.height > 1150: s = s.resize((round(s.width * 1150 / s.height), 1150), Image.LANCZOS)
    fr = Image.new("RGBA", (s.width + 36, s.height + 36), (255, 255, 255, 255)); fr.alpha_composite(s, (18, 18))
    fr = fr.rotate(-2, expand=True, resample=Image.BICUBIC)
    x = (W - fr.width) // 2; y = int(H * cy - fr.height / 2)
    sh = Image.new("RGBA", bg.size, (0, 0, 0, 0)); sh.alpha_composite(Image.new("RGBA", fr.size, (0, 0, 0, 110)), (x + 14, y + 20))
    bg.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16))); bg.alpha_composite(fr, (x, y))
    tag(bg, txt).convert("RGB").save(out)

def panclip(src, out, txt, dur=6, direction=1):
    """Wide painting: slow horizontal pan across the full height (mp4)."""
    im = Image.open(src).convert("RGB"); s = H / im.height; im = im.resize((round(im.width * s), H), Image.LANCZOS)
    im.save("/tmp/_pan_src.png"); t = Image.new("RGBA", (W, H), (0, 0, 0, 0)); tag(t, txt); t.save("/tmp/_pan_tag.png")
    span = max(0, im.width - W); x = f"{span}*t/{dur}" if direction > 0 else f"{span}*(1-t/{dur})"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", str(dur), "-i", "/tmp/_pan_src.png", "-i", "/tmp/_pan_tag.png",
                    "-filter_complex", f"[0:v]crop={W}:{H}:x='{x}':y=0,fps=30[b];[b][1:v]overlay=0:0,format=yuv420p",
                    "-t", str(dur), "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", out], check=True)

def gradient_bg(out, top=(20, 33, 61), bottom=(40, 55, 95)):
    bg = Image.new("RGB", (W, H)); d = ImageDraw.Draw(bg)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * y / H) for i in range(3)))
    bg.save(out)
