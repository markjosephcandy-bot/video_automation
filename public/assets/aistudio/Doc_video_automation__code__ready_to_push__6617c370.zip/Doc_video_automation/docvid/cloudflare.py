"""Cloudflare Workers AI text-to-image (REST)."""
import base64, io, requests
from PIL import Image
from . import config

def generate_image(prompt, out_path, width=768, height=1344, steps=8, seed=None, model=None):
    model = model or config.CF_IMAGE_MODEL
    if not (config.CF_ACCOUNT_ID and config.CF_API_TOKEN):
        raise SystemExit("CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_API_TOKEN not set (see .env.example)")
    url = f"https://api.cloudflare.com/client/v4/accounts/{config.CF_ACCOUNT_ID}/ai/run/{model}"
    body = {"prompt": prompt[:2048]}
    if "flux-1-schnell" in model:
        body["steps"] = min(steps, 8)          # flux-1-schnell: prompt + steps (max 8) only; output is square
    else:
        body.update({"width": width, "height": height, "num_steps": min(steps * 2, 20)})
    if seed is not None:
        body["seed"] = seed
    r = requests.post(url, json=body, headers={"Authorization": f"Bearer {config.CF_API_TOKEN}"}, timeout=180)
    r.raise_for_status()
    if r.headers.get("content-type", "").startswith("image/"):
        raw = r.content
    else:
        j = r.json(); raw = base64.b64decode(j["result"]["image"])
    Image.open(io.BytesIO(raw)).convert("RGB").save(out_path)
    return out_path
