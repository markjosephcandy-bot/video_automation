"""Concatenate segments, add a soft music bed, burn captions, grain, progress bar; loudness -14 LUFS;
speed up just enough to stay under the Shorts limit (captions.srt is rescaled to match)."""
import json, pathlib, re, subprocess, yaml
from . import config

def sh(cmd): subprocess.run(cmd, shell=True, check=True)

def dur(f):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(f)]))

def run(ep_dir):
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text())
    tl = json.loads((ep / "timeline.json").read_text()); T = tl["total"]
    name = f"{sc['title']} - EconoFables Short.mp4".replace("/", "-")
    segs = sorted((ep / "seg").glob("*.mp4"))
    (ep / "list.txt").write_text("".join(f"file '{s.resolve()}'\n" for s in segs))
    cat, bed, raw = ep / "_cat.mp4", ep / "_bed.wav", ep / "_raw.mp4"
    sh(f"ffmpeg -y -v error -f concat -safe 0 -i '{ep/'list.txt'}' -c copy '{cat}'")
    sh(f"ffmpeg -y -v error -f lavfi -i sine=f=130.81:d={T} -f lavfi -i sine=f=196:d={T} -f lavfi -i sine=f=261.63:d={T} -f lavfi -i sine=f=329.63:d={T} "
       f"-filter_complex \"[0][1][2][3]amix=inputs=4,lowpass=f=1200,tremolo=f=0.2:d=0.4,aecho=0.8:0.7:600:0.35,volume=0.5,afade=t=in:d=1.5,afade=t=out:st={T-2}:d=2,aformat=channel_layouts=stereo:sample_rates=48000\" '{bed}'")
    music = sc.get("music")   # optional path to a licensed track
    bedin = f"'{ep/music}'" if music else f"'{bed}'"
    sh(f"ffmpeg -y -v error -i '{cat}' -i {bedin} -filter_complex \"[0:v]noise=alls=4:allf=t,drawbox=x=0:y=0:w=iw:h=10:color=0x14213D@0.6:t=fill,"
       f"drawbox=x=0:y=0:w='iw*t/{T}':h=10:color=0xE9B44C@1:t=fill,subtitles='{ep/'caps.ass'}':fontsdir='{config.FONTS}'[v];"
       f"[0:a]loudnorm=I=-14:TP=-1.5:LRA=11[n];[1:a]volume={0.08 if not music else 0.12}[b];[n][b]amix=inputs=2:duration=first:normalize=0[a]\" "
       f"-map '[v]' -map '[a]' -r 30 -c:v libx264 -preset veryfast -crf 19 -pix_fmt yuv420p -c:a aac -b:a 192k -ar 48000 '{raw}'")
    sp = max(1.0, round(T / config.MAX_SECONDS + 0.005, 2))
    out = ep / name
    sh(f"ffmpeg -y -v error -i '{raw}' -filter_complex \"[0:v]setpts=PTS/{sp}[v];[0:a]atempo={sp},loudnorm=I={config.LUFS}:TP=-1.5:LRA=11[a]\" "
       f"-map '[v]' -map '[a]' -r 30 -c:v libx264 -preset veryfast -crf 19 -pix_fmt yuv420p -c:a aac -b:a 192k -ar 48000 -movflags +faststart '{out}'")
    if sp > 1:
        def p(t): h, m, r = t.split(":"); s, ms = r.split(","); return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000
        def f(x): h = int(x // 3600); m = int(x % 3600 // 60); s = x % 60; return f"{h:02d}:{m:02d}:{int(s):02d},{int(round((s % 1) * 1000)) % 1000:03d}"
        t = (ep / "captions.srt").read_text(); (ep / "captions.srt").write_text(re.sub(r"(\d\d:\d\d:\d\d,\d\d\d)", lambda m: f(p(m.group(1)) / sp), t))
    for x in (cat, bed, raw): x.unlink(missing_ok=True)
    print(f"final: {out.name}  {dur(out):.1f}s  (speed x{sp})")
    return out
