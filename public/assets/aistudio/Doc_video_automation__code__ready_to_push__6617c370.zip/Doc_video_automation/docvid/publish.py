"""youtube.txt: title, description, sources, image credits, AI disclosure, tags. (Upload stays manual.)"""
import json, pathlib, yaml

def run(ep_dir):
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text())
    cr = json.loads((ep / "credits.json").read_text()) if (ep / "credits.json").exists() else {}
    src = json.loads((ep / "sources.json").read_text()) if (ep / "sources.json").exists() else []
    ai = [v.get("what") or k for k, v in cr.items() if v.get("ai")]
    real = sorted({v.get("credit") or v.get("tag") for v in cr.values() if not v.get("ai") and (v.get("credit") or v.get("tag"))})
    out = [f"TITLE\n{sc['title']} #Shorts\n", "DESCRIPTION\n" + (sc.get("description") or "").strip() + "\n"]
    if src: out.append("SOURCES\n" + "\n".join(f"- {s.get('title','')}: {s['url']}" for s in src) + "\n")
    if real: out.append("IMAGE CREDITS\n" + "\n".join(f"- {c}" for c in real) + "\n- Animated infographics, typewriter quote scenes and charts: built by the channel from the sources above\n")
    out.append("AI DISCLOSURE\n" + (f"{len(ai)} frames are AI-generated reconstructions, labelled \"Artist's impression\" on screen ({'; '.join(ai)}). " if ai else "") +
               "The narration uses a synthetic voice. Mark 'altered or synthetic content' when uploading.\n")
    out.append("TAGS\n" + str(sc.get("tags", "")) + "\n")
    (ep / "youtube.txt").write_text("\n".join(out)); return ep / "youtube.txt"
