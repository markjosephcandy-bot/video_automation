"""Quality checks: contact sheet of frames, duration, loudness, resolution."""
import pathlib, subprocess, json
from PIL import Image

def run(video, every=8.0, out=None):
    v = pathlib.Path(video); out = pathlib.Path(out or v.with_suffix(".contact.jpg"))
    d = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(v)]))
    shots = []
    t = 1.0
    while t < d:
        p = f"/tmp/_qa_{len(shots)}.png"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(v), "-frames:v", "1", "-vf", "scale=216:384", p], check=True)
        shots.append(p); t += every
    cols = min(8, len(shots)); rows = (len(shots) + cols - 1) // cols
    sheet = Image.new("RGB", (216 * cols, 384 * rows), "white")
    for k, p in enumerate(shots): sheet.paste(Image.open(p), ((k % cols) * 216, (k // cols) * 384))
    sheet.save(out, quality=85)
    ln = subprocess.run(["ffmpeg", "-nostats", "-i", str(v), "-af", "loudnorm=print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
    j = ln[ln.rfind("{"):]; lufs = json.loads(j[:j.find("}") + 1])["input_i"]
    info = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate", "-of", "csv=p=0", str(v)]).decode().strip()
    rep = {"duration": round(d, 1), "lufs": lufs, "video": info, "contact_sheet": str(out), "under_2_min": d < 120}
    print(json.dumps(rep, indent=1)); return rep
