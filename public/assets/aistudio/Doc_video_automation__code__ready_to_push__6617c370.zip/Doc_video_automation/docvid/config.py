"""Central config: brand, canvas, API keys (from env / .env), font paths."""
import os, pathlib, yaml

ROOT = pathlib.Path(__file__).resolve().parent.parent

def _load_dotenv():
    p = pathlib.Path.cwd() / ".env"
    if not p.exists():
        p = ROOT / ".env"
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
_load_dotenv()

FONTS = pathlib.Path(os.environ.get("DOCVID_FONTS", ROOT / "assets" / "fonts"))
BRAND_FILE = pathlib.Path(os.environ.get("DOCVID_BRAND", ROOT / "brand.yaml"))
BRAND = yaml.safe_load(BRAND_FILE.read_text()) if BRAND_FILE.exists() else {}

def rgb(hexstr):
    h = hexstr.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

NAVY = rgb(BRAND.get("colors", {}).get("primary", "#14213D"))
GOLD = rgb(BRAND.get("colors", {}).get("accent", "#E9B44C"))
CREAM = rgb(BRAND.get("colors", {}).get("paper", "#F6EEDC"))
WHITE = (255, 255, 255); INK = (28, 28, 32); RED = (178, 52, 40); HIGHLIGHT = (255, 214, 90)
CHANNEL = BRAND.get("channel", "ECONOFABLES")
HANDLE = BRAND.get("handle", "@EconoFables")
CTA_LINE = BRAND.get("cta", "Follow EconoFables. Every rupee has a story.")
LOGO = str(ROOT / BRAND.get("logo", "assets/brand/logo.webp"))

# Canvas (Shorts). Long-form 16:9 lives in legacy/longform for now.
W, H, FPS = 1080, 1920, 30
MAX_SECONDS = float(os.environ.get("DOCVID_MAX_SECONDS", 119.5))
LUFS = -14

# Voice (edge-tts gives word timings, which drive captions and the typewriter)
VOICE = os.environ.get("DOCVID_VOICE", "en-US-AndrewMultilingualNeural")
VOICE_RATE = os.environ.get("DOCVID_VOICE_RATE", "+4%")
VOICE_PITCH = os.environ.get("DOCVID_VOICE_PITCH", "-2Hz")

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
GEMINI_PRO_MODEL = os.environ.get("GEMINI_PRO_MODEL", "gemini-2.5-pro")
CF_ACCOUNT_ID = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
CF_API_TOKEN = os.environ.get("CLOUDFLARE_API_TOKEN", "")
CF_IMAGE_MODEL = os.environ.get("CF_IMAGE_MODEL", "@cf/black-forest-labs/flux-1-schnell")
USER_AGENT = os.environ.get("DOCVID_UA", "docvid/0.1 (documentary research; contact via GitHub)")

def font(name, size, weight=None):
    from PIL import ImageFont
    f = ImageFont.truetype(str(FONTS / name), size)
    if weight:
        try: f.set_variation_by_axes([weight])
        except Exception: pass
    return f

BEBAS = lambda s: font("BebasNeue-Regular.ttf", s)
MONT = lambda s, w=500: font("Montserrat[wght].ttf", s, w)
POP = lambda s: font("Poppins-Bold.ttf", s)
POPM = lambda s: font("Poppins-Medium.ttf", s)
PLAY = lambda s, w=500: font("PlayfairDisplay-Italic[wght].ttf", s, w)
TYPE = lambda s: font("CourierPrime-Bold.ttf", s)
