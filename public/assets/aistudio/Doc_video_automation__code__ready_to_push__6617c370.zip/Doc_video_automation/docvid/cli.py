"""docvid command line.

  docvid topics "Indian money history" --n 6            # rare topic options (Gemini + Google Search)
  docvid new episodes/2026-11-06-reis "Alves Reis and the Banco de Portugal notes"
  docvid research  episodes/x "topic" [--notes "..."]   # RESEARCH.md + sources.json
  docvid factcheck episodes/x                           # FACTCHECK.md (grounded re-check)
  docvid script    episodes/x                           # script.yaml + SCRIPT_REVIEW.md  -> HUMAN REVIEW
  docvid tts       episodes/x                           # narration + word timings
  docvid visuals   episodes/x                           # real images, AI frames, infographics -> images/
  docvid render    episodes/x [beat ...]                # seg/NNN.mp4
  docvid finish    episodes/x                           # captions, final mp4, youtube.txt, QA sheet
  docvid build     episodes/x                           # tts -> visuals -> render -> finish (after script approval)
"""
import argparse, pathlib, sys

def main(argv=None):
    ap = argparse.ArgumentParser(prog="docvid", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    a = sp.add_parser("topics"); a.add_argument("niche"); a.add_argument("--n", type=int, default=6); a.add_argument("--avoid", nargs="*"); a.add_argument("--out", default="TOPICS.md")
    for c in ("new", "research"):
        a = sp.add_parser(c); a.add_argument("ep"); a.add_argument("topic"); a.add_argument("--notes", default="")
    for c in ("factcheck", "script", "tts", "timing", "finish", "build", "board"):
        a = sp.add_parser(c); a.add_argument("ep")
    a = sp.add_parser("visuals"); a.add_argument("ep"); a.add_argument("beats", nargs="*", type=int); a.add_argument("--force", action="store_true")
    a = sp.add_parser("render"); a.add_argument("ep"); a.add_argument("beats", nargs="*", type=int)
    a = sp.add_parser("qa"); a.add_argument("video")
    x = ap.parse_args(argv)

    if x.cmd == "topics":
        from . import research; print(research.topics(x.niche, x.n, x.avoid, x.out))
    elif x.cmd in ("new", "research"):
        from . import research; print("wrote", research.brief(x.topic, x.ep, x.notes))
        if x.cmd == "new":
            print("wrote", research.verify(x.ep))
            from . import scriptgen; scriptgen.write(x.ep); print("wrote", scriptgen.board(x.ep))
            print("\nREVIEW SCRIPT_REVIEW.md / script.yaml now. Then: docvid build", x.ep)
    elif x.cmd == "factcheck":
        from . import research; print("wrote", research.verify(x.ep))
    elif x.cmd == "script":
        from . import scriptgen; scriptgen.write(x.ep); print("wrote", scriptgen.board(x.ep))
    elif x.cmd == "board":
        from . import scriptgen; print("wrote", scriptgen.board(x.ep))
    elif x.cmd == "tts":
        from . import tts, timing; tts.run(x.ep); timing.build(x.ep)
    elif x.cmd == "timing":
        from . import timing; print(timing.build(x.ep)["total"])
    elif x.cmd == "visuals":
        from . import visuals; visuals.build(x.ep, x.beats or None, x.force)
    elif x.cmd == "render":
        from . import render; render.run(x.ep, x.beats or None)
    elif x.cmd == "finish":
        _finish(x.ep)
    elif x.cmd == "build":
        from . import tts, timing, visuals, render
        tts.run(x.ep); timing.build(x.ep); visuals.build(x.ep); render.run(x.ep); _finish(x.ep)
    elif x.cmd == "qa":
        from . import qa; qa.run(x.video)

def _finish(ep):
    from . import subs, assemble, publish, qa
    subs.run(ep); out = assemble.run(ep); publish.run(ep); qa.run(out)

if __name__ == "__main__":
    main()
