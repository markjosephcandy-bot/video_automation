"""Vox-style animated clips rendered frame by frame with Pillow, piped to ffmpeg.

Every function takes a spec dict (from script.yaml `visuals`) and a duration in seconds,
and writes a 1080x1920 mp4. Layout keeps clear of: the brand pill (y 118-202), the beat
heading (y 240-~400) and the caption band (y ~1240-1400).
"""
import math, random, subprocess, functools
from PIL import Image, ImageDraw, ImageFilter
from .config import W, H, FPS, NAVY, GOLD, INK, RED, HIGHLIGHT, MONT, BEBAS, POP, POPM, TYPE

@functools.lru_cache(1)
def paper_bg():
    random.seed(7)
    im = Image.new("RGB", (W, H), (238, 228, 206)); n = Image.effect_noise((W, H), 18).convert("L")
    im = Image.composite(Image.new("RGB", (W, H), (226, 214, 188)), im, n.point(lambda v: int(max(0, v - 120) * 0.9)))
    d = ImageDraw.Draw(im)
    for _ in range(260):   # paper fibres
        x = random.randint(0, W); y = random.randint(0, H); l = random.randint(8, 40); a = random.random() * 6.28
        d.line([(x, y), (x + l * math.cos(a), y + l * math.sin(a))], fill=(214, 200, 172), width=1)
    return im.filter(ImageFilter.GaussianBlur(0.6))

def encode(frame_fn, dur, out):
    n = int(dur * FPS) + 1
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame_fn(i / FPS).convert("RGB").tobytes())
    p.stdin.close(); p.wait()
    return out

def ease(x):
    x = max(0, min(1, x)); return 1 - (1 - x) ** 3

def wrap(d, txt, f, maxw):
    out, cur = [], ""
    for w in txt.split():
        t = (cur + " " + w).strip()
        if d.textlength(t, font=f) <= maxw or not cur: cur = t
        else: out.append(cur); cur = w
    out.append(cur); return out

def _src(d, txt, y=1740):
    if txt: d.text((W / 2, y), txt, font=POPM(28), fill=NAVY, anchor="mm")

def _title(d, txt, y=470, size=76):
    if txt: d.text((W / 2, y), txt.upper(), font=BEBAS(size), fill=NAVY, anchor="mm")

# ---------------------------------------------------------------- typewriter
def typewriter(spec, dur, out, t_start=0.5, t_end=None):
    """Exact quote types onto ruled white paper; source at the top; highlight sweeps in at the end."""
    quote = spec["quote"]; hl = spec.get("highlight", ""); header = spec.get("header", ""); sub = spec.get("sub", "")
    t_end = t_end or max(t_start + 1, dur - 1.4)
    TF = TYPE(62); base = paper_bg().convert("RGBA"); y0 = 270
    lines = wrap(ImageDraw.Draw(base), quote, TF, 790); y1 = max(1180, y0 + 250 + len(lines) * 84 + 140)
    hs = quote.find(hl) if hl else -1; he = hs + len(hl)
    sheet = base.copy()
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(sh).rectangle((78, y0 + 14, 1018, y1 + 18), fill=(0, 0, 0, 90))
    sheet.alpha_composite(sh.filter(ImageFilter.GaussianBlur(14))); d = ImageDraw.Draw(sheet)
    d.rectangle((66, y0, 1014, y1), fill=(255, 253, 247))
    for yy in range(y0 + 250, y1 - 60, 84): d.line((110, yy + 66, 970, yy + 66), fill=(214, 226, 240), width=2)
    d.line((150, y0 + 200, 150, y1 - 20), fill=(236, 170, 170), width=2); d.rectangle((66, y0, 1014, y0 + 12), fill=NAVY)
    d.text((110, y0 + 52), header.upper(), font=MONT(34, 800), fill=NAVY)
    d.text((110, y0 + 104), sub, font=MONT(28, 500), fill=(70, 80, 100)); d.line((110, y0 + 160, 970, y0 + 160), fill=GOLD, width=4)
    total = len(quote)
    def frame(t):
        img = sheet.copy(); d = ImageDraw.Draw(img)
        k = int(total * max(0, min(1, (t - t_start) / (t_end - t_start))))
        hp = max(0, min(1, (t - t_end - 0.1) / 0.6)) if hs >= 0 else 0
        pos, y = 0, y0 + 250
        for li, l in enumerate(lines):
            vis = l[:max(0, k - pos)]
            if hp > 0:
                a = max(hs, pos); b = min(he, pos + len(l))
                if b > a:
                    x0 = 180 + d.textlength(l[:a - pos], font=TF); x1 = 180 + d.textlength(l[:b - pos], font=TF)
                    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                    ImageDraw.Draw(lay).rectangle((x0 - 6, y - 4, x0 + (x1 - x0) * hp + 6, y + 62), fill=HIGHLIGHT + (170,))
                    img.alpha_composite(lay); d = ImageDraw.Draw(img)
            d.text((180, y), vis, font=TF, fill=INK)
            if (0 < k - pos <= len(l)) or (k == 0 and li == 0):
                if k < total or int(t * 2.5) % 2 == 0:
                    cx = 180 + d.textlength(vis, font=TF); d.rectangle((cx + 4, y + 4, cx + 30, y + 60), fill=NAVY)
            pos += len(l) + 1; y += 84
        return img
    return encode(frame, dur, out)

# ---------------------------------------------------------------- infographics
def counter(spec, dur, out):
    v = float(spec["value"]); dec = int(spec.get("decimals", 0)); suf = spec.get("suffix", ""); pre = spec.get("prefix", "")
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img); p = ease(t / 2.2)
        _title(d, spec.get("title"), 480, 80)
        d.text((W / 2, 800), f"{pre}{v*p:,.{dec}f}{suf}", font=BEBAS(330 if len(f'{v:,.{dec}f}') < 5 else 230), fill=RED, anchor="mm")
        if spec.get("label"): d.text((W / 2, 1010), spec["label"], font=POP(52), fill=NAVY, anchor="mm")
        if spec.get("sub"): d.text((W / 2, 1080), spec["sub"], font=POPM(38), fill=INK, anchor="mm")
        if spec.get("of_whole"):   # e.g. share of GDP bar
            d.rectangle((120, 1460, 960, 1540), outline=NAVY, width=4)
            d.rectangle((124, 1464, 124 + int(832 * v / 100 * p), 1536), fill=RED)
            d.text((120, 1430), spec["of_whole"], font=POPM(30), fill=NAVY, anchor="ls")
        _src(d, spec.get("source")); return img
    return encode(frame, dur, out)

def donut(spec, dur, out):
    vals = spec["values"]; cols = [NAVY, GOLD, (150, 150, 150), RED, (90, 120, 160)]
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img)
        _title(d, spec.get("title"), 470)
        p = ease(t / 1.6); cx, cy, R = 540, 850, 300; start = -90
        for k, (_, v) in enumerate(vals):
            ext = 360 * v / 100 * p; d.pieslice((cx - R, cy - R, cx + R, cy + R), start, start + ext, fill=cols[k % 5]); start += ext
        d.ellipse((cx - 170, cy - 170, cx + 170, cy + 170), fill=(238, 228, 206))
        d.text((cx, cy - 20), f"{vals[0][1]*p:.1f}%", font=BEBAS(130), fill=NAVY, anchor="mm")
        d.text((cx, cy + 60), spec.get("center_label", vals[0][0]), font=POP(36), fill=NAVY, anchor="mm")
        if ease((t - 1.6) / 0.5) > 0:
            for k, (l, v) in enumerate(vals[:3]):
                y = 1450 + k * 80; d.rectangle((210, y - 22, 254, y + 22), fill=cols[k % 5]); d.text((280, y), f"{l}: {v}%", font=POP(42), fill=INK, anchor="lm")
        _src(d, spec.get("source")); return img
    return encode(frame, dur, out)

def bars(spec, dur, out):
    data = spec["bars"]; suf = spec.get("suffix", ""); mx = max(v for _, v in data)
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img); p = ease(t / 1.8)
        _title(d, spec.get("title"), 470)
        base = 1180; sc = 560 / mx; n = len(data); bw = min(220, 700 // n - 40); gap = (840 - n * bw) / max(1, n)
        for k, (lab, v) in enumerate(data):
            x = 120 + gap / 2 + k * (bw + gap); h = v * sc * p; c = RED if k == n - 1 else NAVY
            d.rectangle((x, base - h, x + bw, base), fill=c)
            d.text((x + bw / 2, base - h - 20), f"{v*p:.1f}{suf}", font=BEBAS(96 if n <= 3 else 64), fill=c, anchor="ms")
            d.text((x + bw / 2, base + 50), str(lab), font=POP(40 if n <= 3 else 30), fill=INK, anchor="mm")
        d.line((100, base, 980, base), fill=NAVY, width=4)
        _src(d, spec.get("source"), 1690); _src(d, spec.get("note"), 1740); return img
    return encode(frame, dur, out)

def line(spec, dur, out):
    """points: [[label, value], ...] (labels only used for first/last axis ticks); marks: [[index, text], ...]"""
    pts = [v for _, v in spec["points"]]; labs = [l for l, _ in spec["points"]]
    lo, hi = min(pts), max(pts); pad = (hi - lo) * 0.12 or 1; lo -= pad; hi += pad
    X = lambda i: 130 + i / max(1, len(pts) - 1) * 830; Y = lambda v: 1180 - (v - lo) / (hi - lo) * 640
    marks = {int(i): txt for i, txt in spec.get("marks", [])}
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img)
        for g in range(5):
            v = lo + (hi - lo) * g / 4; d.line((130, Y(v), 960, Y(v)), fill=(210, 198, 172), width=2)
            d.text((120, Y(v)), f"{v:,.0f}", font=POPM(24), fill=NAVY, anchor="rm")
        m = int(len(pts) * ease(t / (dur * 0.75)))
        if m > 1: d.line([(X(i), Y(pts[i])) for i in range(m)], fill=NAVY, width=7, joint="curve")
        for i, txt in marks.items():
            if m > i:
                d.ellipse((X(i) - 16, Y(pts[i]) - 16, X(i) + 16, Y(pts[i]) + 16), fill=GOLD, outline=NAVY, width=4)
                right = X(i) < W / 2
                d.text((X(i) + (30 if right else -30), Y(pts[i]) + (40 if pts[i] < (lo + hi) / 2 else -50)), txt, font=POP(36), fill=RED, anchor="lm" if right else "rm")
        d.text((130, 1215), str(labs[0]), font=POPM(26), fill=NAVY); d.text((960, 1215), str(labs[-1]), font=POPM(26), fill=NAVY, anchor="ra")
        if spec.get("title"): d.text((W / 2, 1228), spec["title"].upper(), font=BEBAS(48), fill=NAVY, anchor="mm")
        _src(d, spec.get("source")); return img
    return encode(frame, dur, out)

def timeline(spec, dur, out):
    items = spec["items"]; n = len(items)
    ys = [470 + k * 230 for k in range(min(n, 4))]
    if n == 4: ys[-1] = 1500   # jump the caption band
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img)
        yl = ys[0] + (ys[-1] - ys[0]) * ease(t / (dur * 0.8)); d.line((200, ys[0], 200, yl), fill=NAVY, width=8)
        for k, (yr, txt) in enumerate(items[:4]):
            a = ease((t - k * dur * 0.18) / 0.4)
            if a <= 0: continue
            r = int(26 * a); d.ellipse((200 - r, ys[k] - r, 200 + r, ys[k] + r), fill=GOLD, outline=NAVY, width=5)
            x = 250 - int(40 * (1 - a))
            d.text((x, ys[k] - 58), str(yr).upper(), font=BEBAS(84), fill=NAVY)
            for j, l in enumerate(wrap(d, txt, POP(38), 760)[:2]): d.text((x, ys[k] + 34 + j * 46), l, font=POP(38), fill=INK)
        _src(d, spec.get("footer"), 1790); return img
    return encode(frame, dur, out)

def ladder(spec, dur, out):
    rungs = spec["rungs"]; cols = [NAVY, NAVY, (90, 100, 120), RED, RED]
    def frame(t):
        img = paper_bg().convert("RGBA"); d = ImageDraw.Draw(img)
        for k, txt in enumerate(rungs[:4]):
            a = ease((t - 0.3 - k * 0.75) / 0.45)
            if a <= 0: continue
            c = cols[k] if k < len(rungs) - 1 else RED
            y = 600 + k * 165; x = 90 + k * 30 - int(60 * (1 - a))
            d.rounded_rectangle((x, y, x + 870 - k * 30, y + 120), 18, fill=(255, 253, 247), outline=c, width=5)
            d.ellipse((x + 20, y + 20, x + 100, y + 100), fill=c); d.text((x + 60, y + 60), str(k + 1), font=BEBAS(70), fill=(255, 255, 255), anchor="mm")
            d.text((x + 120, y + 60), txt, font=POP(34), fill=INK, anchor="lm")
            if k < len(rungs) - 1: d.polygon([(x + 60, y + 128), (x + 80, y + 150), (x + 40, y + 150)], fill=c)
        if ease((t - 3.4) / 0.5) > 0:
            if spec.get("note"): d.text((W / 2, 1470), spec["note"], font=POP(44), fill=RED, anchor="mm")
            if spec.get("sub"): d.text((W / 2, 1540), spec["sub"], font=POPM(30), fill=NAVY, anchor="mm")
        return img
    return encode(frame, dur, out)

KINDS = {"typewriter": typewriter, "counter": counter, "donut": donut, "bars": bars, "line": line, "timeline": timeline, "ladder": ladder}
