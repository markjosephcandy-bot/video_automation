"""docvid: research -> script -> visuals -> voice -> render pipeline for documentary-style finance/history videos."""
__version__ = "0.1.0"
