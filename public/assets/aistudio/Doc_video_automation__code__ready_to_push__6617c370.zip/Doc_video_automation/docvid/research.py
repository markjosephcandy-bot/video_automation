"""Topic discovery and grounded research with Gemini + Google Search."""
import json, pathlib
from . import gemini, config

P = config.ROOT / "prompts"
RULES = (P / "rules.md").read_text()

def topics(niche, n=6, avoid=None, out=None):
    prompt = (P / "topics.md").read_text().format(n=n, niche=niche, avoid=(" (already covered: " + ", ".join(avoid) + ")") if avoid else "")
    text, src = gemini.generate(prompt, system=RULES, search=True, model=config.GEMINI_PRO_MODEL)
    md = text + "\n\n## Search sources\n" + "\n".join(f"- {s['title']}: {s['url']}" for s in src)
    if out: pathlib.Path(out).write_text(md)
    return md

def brief(topic, ep_dir, notes="", fmt="YouTube Short (under 2 minutes)"):
    ep = pathlib.Path(ep_dir); ep.mkdir(parents=True, exist_ok=True)
    prompt = (P / "research.md").read_text().format(topic=topic, notes=notes or "-", format=fmt)
    text, src = gemini.generate(prompt, system=RULES, search=True, model=config.GEMINI_PRO_MODEL)
    md = f"# Research: {topic}\n\n" + text + "\n\n## Grounding sources (from Google Search)\n" + \
        "\n".join(f"- {s['title']}: {s['url']}" for s in src) + "\n"
    (ep / "RESEARCH.md").write_text(md)
    (ep / "sources.json").write_text(json.dumps(src, indent=1))
    return ep / "RESEARCH.md"

def verify(ep_dir):
    """Second pass: ask Gemini (grounded) to re-check every fact in the brief and list problems."""
    ep = pathlib.Path(ep_dir); b = (ep / "RESEARCH.md").read_text()
    prompt = ("Fact-check this research brief claim by claim using Google Search. For each numbered fact say "
              "CONFIRMED / WRONG (with the correct value and source) / UNVERIFIABLE. Then list any date, percentage "
              "or quote that is likely misattributed.\n\n" + b)
    text, src = gemini.generate(prompt, system=RULES, search=True, model=config.GEMINI_PRO_MODEL)
    (ep / "FACTCHECK.md").write_text(text + "\n\n## Sources\n" + "\n".join(f"- {s['url']}" for s in src))
    return ep / "FACTCHECK.md"
