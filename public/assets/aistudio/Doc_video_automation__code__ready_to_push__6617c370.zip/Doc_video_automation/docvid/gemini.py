"""Minimal Gemini REST client (generateContent). Supports Google Search grounding and JSON output.

Note: grounding (google_search tool) and JSON-mode can't always be combined, so research
runs grounded -> markdown first, then a second ungrounded call structures it into JSON.
"""
import json, time, requests
from . import config

URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

def generate(prompt, system=None, search=False, json_schema=None, model=None, temperature=0.4, retries=3):
    """Returns (text, sources). sources = [{'title','url'}] from grounding metadata."""
    if not config.GEMINI_API_KEY:
        raise SystemExit("GEMINI_API_KEY is not set (see .env.example)")
    body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": temperature}}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    if search:
        body["tools"] = [{"google_search": {}}]
    if json_schema is not None:
        body["generationConfig"]["responseMimeType"] = "application/json"
        if json_schema:
            body["generationConfig"]["responseSchema"] = json_schema
    url = URL.format(model=model or config.GEMINI_MODEL)
    for a in range(retries):
        r = requests.post(url, json=body, headers={"x-goog-api-key": config.GEMINI_API_KEY}, timeout=300)
        if r.status_code in (429, 500, 503):
            time.sleep(5 * (a + 1)); continue
        r.raise_for_status(); break
    data = r.json()
    cand = (data.get("candidates") or [{}])[0]
    text = "".join(p.get("text", "") for p in cand.get("content", {}).get("parts", []))
    sources = []
    for ch in cand.get("groundingMetadata", {}).get("groundingChunks", []) or []:
        w = ch.get("web") or {}
        if w.get("uri"):
            sources.append({"title": w.get("title", ""), "url": w["uri"]})
    return text, sources

def generate_json(prompt, system=None, schema=None, model=None):
    text, _ = generate(prompt, system=system, json_schema=schema or {}, model=model, temperature=0.3)
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`").split("\n", 1)[1].rsplit("```", 1)[0]
    return json.loads(t)
