"""Word-highlight captions (ASS, burned in) + captions.srt for YouTube + transcript.txt.
Captions are 1-3 words, Poppins 92 px, centred at y=1320; muted where a typewriter scene shows the words."""
import json, pathlib, re, yaml
from .config import FONTS
from .util import beats as all_beats
from PIL import ImageFont

PROTECT_DEFAULT = [["bank", "of", "england"], ["reserve", "bank", "of", "india"]]
FUNC = {"in", "on", "from", "the", "a", "to", "of"}

def ts_srt(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h:02d}:{m:02d}:{int(s):02d},{int(round((s % 1) * 1000)) % 1000:03d}"

def ts_ass(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60; return f"{h}:{m:02d}:{s:05.2f}"

def run(ep_dir):
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text()); bs = all_beats(sc)
    tl = json.loads((ep / "timeline.json").read_text())
    PF = ImageFont.truetype(str(FONTS / "Poppins-Bold.ttf"), 138); CW = lambda t: PF.getlength(t.upper()) * 0.39
    protect = [[w.lower() for w in p.split()] for p in sc.get("protect", [])] + PROTECT_DEFAULT
    norm = lambda x: re.sub(r"[^\w%.-]", "", x).lower()
    groups, all_words = [], []
    for i, b in enumerate(bs):
        row = tl["beats"][i]; words = json.loads((ep / f"tts/{i:03d}.json").read_text())
        toks = b["say"].split(); ti = 0; ws = []
        for st, du, tx in words:
            disp = tx
            for j in range(ti, min(ti + 4, len(toks))):
                if re.sub(r"[^\w]", "", toks[j]).lower().startswith(re.sub(r"[^\w]", "", tx).lower()[:3]):
                    disp = toks[j]; ti = j + 1; break
            ws.append([row["t0"] + row["pre"] + st, row["t0"] + row["pre"] + st + du, disp])
        all_words += ws
        ws = [w for w in ws if not any(a <= w[0] < z for a, z in tl.get("nocap", []))]
        units, k = [], 0
        while k < len(ws):
            hit = next((len(p) for p in protect if [norm(w[2]) for w in ws[k:k + len(p)]] == p), None)
            n = hit or 1; units.append(ws[k:k + n]); k += n
        mu = []
        for u in units:
            if mu and len(u) > 1 and len(mu[-1]) == 1 and norm(mu[-1][0][2]) in FUNC and len(u) < 3 and mu[-1][0][2][-1] not in ".,?!;:":
                mu[-1] = mu[-1] + u
            else: mu.append(u)
        cur = []
        for u in mu:
            if cur and (len(cur) + len(u) > 3 or CW(" ".join(x[2] for x in cur + u)) > 800):
                groups.append(cur); cur = []
            cur += u
            if u[-1][2][-1] in ".,?!;:": groups.append(cur); cur = []
        if cur: groups.append(cur)
    # YouTube SRT: every spoken word (including typewriter scenes), sentence-ish chunks
    srt, chunk = [], []
    for w in all_words:
        chunk.append(w)
        if len(chunk) >= 7 or w[2][-1] in ".?!":
            srt.append(chunk); chunk = []
    if chunk: srt.append(chunk)
    ends = [min(c[-1][1] + 0.15, srt[k + 1][0][0]) if k + 1 < len(srt) else c[-1][1] + 0.15 for k, c in enumerate(srt)]
    (ep / "captions.srt").write_text("\n".join(f"{k+1}\n{ts_srt(c[0][0])} --> {ts_srt(ends[k])}\n{' '.join(x[2] for x in c)}\n" for k, c in enumerate(srt)))
    hdr = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 2\n\n[V4+ Styles]\n"
           "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
           "Style: Cap,Poppins,92,&H00FFFFFF,&H00FFFFFF,&H003D2114,&H96000000,1,0,0,0,100,100,0,0,1,6,3,5,60,170,0,1\n\n[Events]\n"
           "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
    ev = []
    for k, g in enumerate(groups):
        gend = g[-1][1] + 0.25
        if k + 1 < len(groups): gend = min(gend, groups[k + 1][0][0])
        words = [x[2] for x in g]; cut = len(words) if CW(" ".join(words)) <= 800 or len(words) < 2 else (len(words) + 1) // 2
        for j, w in enumerate(g):
            e = g[j + 1][0] if j + 1 < len(g) else gend
            parts = [("{\\c&H4CB4E9&}" + x.upper() + "{\\c&HFFFFFF&}") if jj == j else x.upper() for jj, x in enumerate(words)]
            txt = " ".join(parts[:cut]) + (("\\N" + " ".join(parts[cut:])) if cut < len(parts) else "")
            ev.append(f"Dialogue: 0,{ts_ass(w[0])},{ts_ass(e)},Cap,,0,0,0,,{{\\an5\\pos(540,1320)}}{txt}")
    (ep / "caps.ass").write_text(hdr + "\n".join(ev) + "\n")
    (ep / "transcript.txt").write_text("\n".join(b["say"] for b in bs) + "\n")
