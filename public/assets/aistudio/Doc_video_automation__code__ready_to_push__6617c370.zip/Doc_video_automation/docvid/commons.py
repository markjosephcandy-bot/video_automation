"""Find real, licensed historical images on Wikimedia Commons (with artist + licence for credits)."""
import re, requests
from . import config

API = "https://commons.wikimedia.org/w/api.php"
HDR = {"User-Agent": config.USER_AGENT}

def _clean(html):
    return re.sub(r"<[^>]+>", "", html or "").strip()

def search(query, limit=8):
    """Returns [{title,url,thumb,width,height,artist,licence,licence_url,description,page}]"""
    p = {"action": "query", "format": "json", "generator": "search", "gsrsearch": f"filetype:bitmap {query}",
         "gsrnamespace": 6, "gsrlimit": limit, "prop": "imageinfo", "iiprop": "url|size|extmetadata", "iiurlwidth": 1600}
    r = requests.get(API, params=p, headers=HDR, timeout=60); r.raise_for_status()
    out = []
    for pg in (r.json().get("query", {}).get("pages", {}) or {}).values():
        ii = (pg.get("imageinfo") or [{}])[0]; m = ii.get("extmetadata", {})
        out.append({"title": pg["title"], "url": ii.get("url"), "thumb": ii.get("thumburl"),
                    "width": ii.get("width"), "height": ii.get("height"),
                    "artist": _clean(m.get("Artist", {}).get("value")),
                    "licence": _clean(m.get("LicenseShortName", {}).get("value")),
                    "licence_url": m.get("LicenseUrl", {}).get("value", ""),
                    "description": _clean(m.get("ImageDescription", {}).get("value"))[:300],
                    "page": ii.get("descriptionurl")})
    return out

def download(item, path):
    url = item.get("thumb") or item["url"]
    r = requests.get(url, headers=HDR, timeout=120); r.raise_for_status()
    open(path, "wb").write(r.content); return path

def credit(item):
    who = item.get("artist") or "unknown"
    return f"{item['title'].replace('File:', '')}: {who}, {item.get('licence') or 'licence unknown'} (Wikimedia Commons)"

MET_SEARCH = "https://collectionapi.metmuseum.org/public/collection/v1.1/search"   # v1 search endpoint is retired
MET_OBJECT = "https://collectionapi.metmuseum.org/public/collection/v1/objects/{}"

def met_search(query, limit=5):
    """Open-access (CC0) objects from The Met."""
    r = requests.get(MET_SEARCH, params={"q": query, "hasImages": "true", "isPublicDomain": "true"}, headers=HDR, timeout=60)
    ids = (r.json() or {}).get("objectIDs") or []
    out = []
    for i in ids[:limit]:
        o = requests.get(MET_OBJECT.format(i), headers=HDR, timeout=60).json()
        if o.get("primaryImage"):
            out.append({"title": o.get("title"), "url": o["primaryImage"], "date": o.get("objectDate"),
                        "accession": o.get("accessionNumber"), "licence": "CC0", "artist": "The Metropolitan Museum of Art",
                        "page": o.get("objectURL")})
    return out
