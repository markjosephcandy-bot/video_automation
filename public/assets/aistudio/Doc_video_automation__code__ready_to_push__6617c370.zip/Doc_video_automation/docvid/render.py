"""Per-beat segment renderer: Ken Burns stills / animated clips + brand overlay + narration -> seg/NNN.mp4"""
import json, pathlib, subprocess, yaml
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageFilter
from .config import W, H, FPS, GOLD, NAVY, WHITE, CREAM, CHANNEL, HANDLE, LOGO, BEBAS, MONT, POP
from .util import beats as all_beats
from .timing import slots
from .anim import wrap

Y = GOLD

def shadow_text(img, xy, txt, f, fill, anchor="la", sh=3, blur=4):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((xy[0] + sh, xy[1] + sh), txt, font=f, fill=(0, 0, 0, 170), anchor=anchor)
    img.alpha_composite(lay.filter(ImageFilter.GaussianBlur(blur))); ImageDraw.Draw(img).text(xy, txt, font=f, fill=fill, anchor=anchor)

def overlay(b):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    # brand pill
    lf = MONT(46, 800); tw = d.textlength(CHANNEL, font=lf); pw, ph = tw + 84, 84; px0 = (W - pw) / 2; py0 = 118
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle((px0 + 4, py0 + 8, px0 + pw + 4, py0 + ph + 8), ph / 2, fill=(0, 0, 0, 120))
    img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(10))); d = ImageDraw.Draw(img)
    d.rounded_rectangle((px0, py0, px0 + pw, py0 + ph), ph / 2, fill=NAVY + (225,), outline=Y + (200,), width=2)
    d.text((W / 2, py0 + ph / 2 + 1), CHANNEL, font=lf, fill=Y, anchor="mm")
    s = b.get("show")
    if not s: return img
    if s["type"] == "heading":   # small Poppins heading in a translucent navy bar near the top
        f = POP(54); em = set(w.upper() for w in s.get("emphasis", []))
        lines = wrap(d, s["text"].upper().replace("?", ""), f, 820)
        lw = max(d.textlength(l, font=f) for l in lines); bh = len(lines) * 68 + 44; bw = lw + 70; x0 = (W - bw) / 2; y0 = 240
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).rounded_rectangle((x0, y0, x0 + bw, y0 + bh), 22, fill=NAVY + (165,))
        img.alpha_composite(lay); d = ImageDraw.Draw(img); d.rectangle((x0 + 22, y0 + bh - 6, x0 + bw - 22, y0 + bh - 3), fill=Y + (230,))
        y = y0 + 76
        for l in lines:
            x = (W - d.textlength(l, font=f)) / 2
            for w in l.split():
                shadow_text(img, (x, y), w, f, Y if w.strip(".,!") in em else WHITE, "ls", 2, 3); x += d.textlength(w + " ", font=f)
            y += 68
    elif s["type"] == "cta":
        lg = Image.open(LOGO).convert("RGBA").resize((320, 320), Image.LANCZOS)
        m = Image.new("L", (320, 320), 0); ImageDraw.Draw(m).ellipse((0, 0, 319, 319), fill=255)
        ring = Image.new("RGBA", (340, 340), (0, 0, 0, 0)); ImageDraw.Draw(ring).ellipse((0, 0, 339, 339), fill=Y + (255,))
        img.alpha_composite(ring, (int(W / 2 - 170), 280)); img.paste(lg, (int(W / 2 - 160), 290), m)
        shadow_text(img, (W / 2, 700), HANDLE.upper(), BEBAS(110), WHITE, "ms", 4, 6)
        d = ImageDraw.Draw(img); f = POP(50); bw = d.textlength("FOLLOW", font=f) + 110; x0 = (W - bw) / 2
        d.rounded_rectangle((x0, 745, x0 + bw, 841), 48, fill=Y + (255,)); d.text((W / 2, 795), "FOLLOW", font=f, fill=NAVY, anchor="mm")
    return img

def render_beat(ep, i, b, row):
    (ep / "ov").mkdir(exist_ok=True); (ep / "seg").mkdir(exist_ok=True)
    ov = ep / f"ov/{i:03d}.png"; overlay(b).save(ov)
    D = row["dur"]; ins, fc = [], []
    sl = slots(b, D)
    for k, (v, s0, sd) in enumerate(sl):
        f = ep / "images" / v["file"]; fr = int(round(sd * FPS)) + 1; ins += ["-i", str(f)]
        if f.suffix == ".mp4":
            fc.append(f"[{k}:v]scale={W}:{H},setsar=1,fps={FPS},tpad=stop_mode=clone:stop_duration=2,trim=0:{sd:.3f},setpts=PTS-STARTPTS[v{k}]"); continue
        mode = (i + k) % 4
        z = f"1.0+0.10*on/{fr}" if mode != 1 else f"1.10-0.10*on/{fr}"
        if mode == 2: x, y = f"(iw-iw/zoom)*on/{fr}", "(ih-ih/zoom)/2"
        elif mode == 3: x, y = "(iw-iw/zoom)/2", f"(ih-ih/zoom)*(1-on/{fr})"
        else: x, y = "(iw-iw/zoom)/2", "(ih-ih/zoom)/2"
        fc.append(f"[{k}:v]scale=2160:3840,setsar=1,zoompan=z='{z}':x='{x}':y='{y}':d={fr}:s={W}x{H}:fps={FPS},trim=0:{sd:.3f},setpts=PTS-STARTPTS[v{k}]")
    n = len(sl)
    ins += ["-loop", "1", "-t", f"{D:.3f}", "-i", str(ov), "-i", str(ep / f"tts/{i:03d}.mp3")]
    fc.append("".join(f"[v{k}]" for k in range(n)) + f"concat=n={n}:v=1:a=0,format=yuv420p[bg]")
    fc.append(f"[{n}:v]format=rgba" + ("" if i == 0 else f",fade=t=in:st={row['pre']+0.05:.2f}:d=0.25:alpha=1") + "[o]")
    fc.append("[bg][o]overlay=0:0:shortest=1,format=yuv420p[v]")
    ms = int(row["pre"] * 1000)
    fc.append(f"[{n+1}:a]atrim=0:{row['adur']:.3f},afade=t=out:st={max(0,row['adur']-0.06):.3f}:d=0.06,adelay={ms}|{ms},apad,atrim=0:{D:.3f},aformat=sample_rates=48000:channel_layouts=stereo[a]")
    cmd = ["ffmpeg", "-y", "-v", "error"] + ins + ["-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]", "-t", f"{D:.3f}", "-r", str(FPS),
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "19", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", str(ep / f"seg/{i:03d}.mp4")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode: print("FAIL beat", i, r.stderr[-800:])
    return i

def run(ep_dir, only=None, workers=3):
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text()); bs = all_beats(sc)
    tl = json.loads((ep / "timeline.json").read_text())
    sel = only or range(len(bs))
    with ThreadPoolExecutor(workers) as ex:
        list(ex.map(lambda i: render_beat(ep, i, bs[i], tl["beats"][i]), sel))
