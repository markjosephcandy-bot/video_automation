"""Turn RESEARCH.md into script.yaml (beats with narration, headings and visual specs)."""
import pathlib, yaml
from . import gemini, config

P = config.ROOT / "prompts"

def write(ep_dir, fmt="YouTube Short under 2 minutes", max_ai=5):
    ep = pathlib.Path(ep_dir)
    brief = (ep / "RESEARCH.md").read_text()
    fc = ep / "FACTCHECK.md"
    if fc.exists():
        brief += "\n\n# FACT-CHECK RESULTS (obey: drop or correct anything WRONG/UNVERIFIABLE)\n" + fc.read_text()
    prompt = (P / "script.md").read_text().format(format=fmt, brief=brief, cta=config.CTA_LINE, max_ai=max_ai)
    data = gemini.generate_json(prompt, system=(P / "rules.md").read_text(), model=config.GEMINI_PRO_MODEL)
    beats = []
    for i, b in enumerate(data["beats"]):
        nb = {"say": b["say"].strip()}
        if b.get("heading"):
            nb["show"] = {"type": "heading", "text": b["heading"], "emphasis": [w.upper() for w in b.get("emphasis", [])]}
        vis = b.get("visuals") or []
        for k, v in enumerate(vis):
            v.setdefault("file", _fname(i, k, v))
        nb["visuals"] = vis
        if b.get("facts"): nb["facts"] = b["facts"]
        beats.append(nb)
    beats[-1] = {"say": config.CTA_LINE, "show": {"type": "cta"}, "visuals": [{"kind": "cta", "file": "cta_bg.png"}]}
    sc = {"title": data["title"].replace("?", ""), "format": "short", "chapters": [{"title": None, "beats": beats}],
          "description": data.get("description", ""), "tags": data.get("tags", "")}
    (ep / "script.yaml").write_text(yaml.safe_dump(sc, allow_unicode=True, sort_keys=False, width=1000))
    return ep / "script.yaml"

def _fname(i, k, v):
    kind = v.get("kind", "real")
    ext = "mp4" if kind in ("typewriter", "counter", "donut", "bars", "line", "timeline", "ladder") else "png"
    return f"b{i:02d}_{k}_{kind}.{ext}"

from .util import beats

def board(ep_dir):
    """Markdown review sheet: narration + planned visuals, for the human to approve before production."""
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text())
    lines = [f"# {sc['title']}\n"]
    for i, b in enumerate(beats(sc)):
        lines.append(f"**{i+1}.** {b['say']}")
        if b.get("show", {}).get("text"): lines.append(f"  - heading: {b['show']['text']}")
        for v in b.get("visuals", []):
            lines.append(f"  - [{v.get('kind')}] {v.get('what') or v.get('quote') or v.get('title') or v.get('prompt','')[:90]}")
    (ep / "SCRIPT_REVIEW.md").write_text("\n".join(lines) + "\n")
    return ep / "SCRIPT_REVIEW.md"
