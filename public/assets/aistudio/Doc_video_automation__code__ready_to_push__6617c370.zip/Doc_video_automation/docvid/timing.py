"""Beat timing from TTS word boundaries -> timeline.json (used by visuals, render and captions)."""
import json, subprocess, pathlib, yaml
from .util import beats as all_beats

ANIM = ("typewriter", "counter", "donut", "bars", "line", "timeline", "ladder")

def _dur(f):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]))

def slots(b, D):
    vis = b.get("visuals") or [{"file": f} for f in b.get("images", [])]
    n = max(1, len(vis)); w = b.get("w") or [1 / n] * n
    out, t = [], 0
    for k, v in enumerate(vis):
        out.append((v, t, D * w[k])); t += D * w[k]
    return out

def build(ep_dir):
    ep = pathlib.Path(ep_dir); sc = yaml.safe_load((ep / "script.yaml").read_text()); bs = all_beats(sc)
    t, rows, nocap = 0.0, [], []
    for i, b in enumerate(bs):
        words = json.loads((ep / f"tts/{i:03d}.json").read_text())
        end = words[-1][0] + words[-1][1] if words else _dur(str(ep / f"tts/{i:03d}.mp3"))
        adur = min(_dur(str(ep / f"tts/{i:03d}.mp3")), end + 0.12)
        pre = 0.0 if i == 0 else 0.05; post = 0.7 if i == len(bs) - 1 else 0.08
        D = pre + adur + post
        rows.append({"t0": t, "pre": pre, "adur": adur, "dur": D})
        for v, s0, sd in slots(b, D):
            if v.get("kind") == "typewriter":   # the paper *is* the caption; mute karaoke captions there
                nocap.append([t + s0, t + s0 + sd])
        t += D
    tl = {"total": t, "beats": rows, "nocap": nocap}
    (ep / "timeline.json").write_text(json.dumps(tl, indent=1))
    return tl
