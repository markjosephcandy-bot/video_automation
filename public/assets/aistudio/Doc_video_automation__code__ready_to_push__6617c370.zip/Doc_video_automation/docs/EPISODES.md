# Episode log (topics already covered; don't repeat)

| Date | Format | Title / topic | Status |
|---|---|---|---|
| earlier | long | Al-Ghazali and inflation | old channel |
| earlier | long | When India Pawned Its Gold (1991 BoP crisis) | old channel |
| 2026-11-01 | long | When the Internet Bubble Burst (dot-com, Ketan Parekh) | made |
| 2026-11-01 | long | Your Salary in Akbar's India (Ain-i-Akbari wages, c.1595) | made, needs rebrand |
| 2026-11-02 | long | The Bank Heist Before Binance (Bangladesh Bank 2016) | made, unpublished |
| 2026-11-02 | short | Dubai Once Ran on Indian Rupees (Gulf rupee) | made |
| 2026-11-02 | short | Your ₹1 Note Is Legally a Coin | made |
| 2026-11-02 | short | Jagat Seth, banker of the world | published (59% swiped away) |
| 2026-11-03 | long | The Oil Weapon: 1973's shock and your rupee | made, unpublished |
| 2026-11-03 | short | Virji Vora: Shivaji looted Surat's merchant prince (EN + Hindi) | made, unpublished |
| 2026-11-03 | short | Alves Reis: Portugal's own printer printed his money | made, unpublished |
| 2026-11-04 | long | Silver Thursday: the Hunt brothers | made, unpublished |
| 2026-11-04 | short | Jakob Fugger: he paid for an emperor's crown | made, unpublished |
| 2026-11-04 | short | The Rich Get New Money First (money creation, Cantillon) | made, Vox-style v2 |

Backlog ideas: Souk al-Manakh 1982; Iraq's Swiss dinar; Nauru; Kabul Bank; Somalia shilling; RBI Haj notes;
Burma notes; 1978 demonetisation; Nizam's £1m; 1911 Pig Rupee; "Money Is a Promise" 13-min documentary.
