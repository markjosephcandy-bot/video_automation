# Style guide (Vox-style history Shorts)

Layout of a 1080x1920 frame (top to bottom):
- y 0-10: progress bar (gold on navy).
- y 118-202: brand pill `E C O N O F A B L E S` (Montserrat 800, gold on navy).
- y 240-~400: beat heading, Poppins Bold 54, uppercase, 1-2 lines, gold emphasis word, translucent navy bar.
- y ~420-1230: main picture area (infographic content lives here).
- y ~1240-1400: karaoke captions (Poppins 92, white, active word gold, navy outline).
- y ~1420-1780: infographic legends, sources (Poppins Medium 28), image source tag at y≈1510.

Scenes
- Typewriter document: cream paper background, white ruled sheet, navy top rule, header = institution (Montserrat 800),
  sub = publication + date, Courier Prime Bold 62 typed text, highlighter (#FFD65A, 67% alpha) on the key phrase.
- Infographics: cream paper with fibres, Bebas Neue titles in navy, red #B23428 for the key number, gold for markers.
- Photos: full-bleed, gently brightened (+8% brightness, +12% contrast, +15% colour), slow Ken Burns (4 motion modes).
- Objects/books: white-bordered print on paper, rotated -2°, soft shadow.
- AI frames: bright, warm, period-accurate; label "Artist's impression (AI-generated)".

Voice: en-US-AndrewMultilingualNeural, +4% rate, -2 Hz pitch. Music: soft generated pad at -22 dB under the voice
(swap in a licensed track via `music:` in script.yaml).
