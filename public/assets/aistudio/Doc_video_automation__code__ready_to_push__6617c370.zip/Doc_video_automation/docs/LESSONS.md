# Lessons learned (newest first). Add one after every review or upload.

## Visuals
- 2026-11-04: Screenshot of a PDF with a highlighter was unreadable on phones -> typewriter-on-paper scene synced to narration, large type, source on top.
- 2026-11-04: Grey clay tablet / tally / dark Turner painting felt dull -> bright AI reconstructions (labelled) + brightened real photos + animated infographics.
- 2026-11-04: Infographic titles collided with 2-line beat headings -> drop the beat heading on infographic-only beats, or move chart titles below the chart.
- 2026-11-04: AI fire scene of 1834 Westminster showed Big Ben (anachronism) -> regenerate with explicit "old medieval palace, no clock tower".
- 2026-11-03: Every image must fill 9:16 (no empty bands); headings small and off faces; no heavy dark glow/vignette.
- 2026-11-03: Use originals (Commons, Met, Rijksmuseum, archive.org scans) wherever possible; generate only what doesn't exist.

## Story / retention
- Jagat Seth Short: 59% swiped away, 22 s average on a 55 s Short. Cause: question opener + "That's the legend". Fix: name the subject and the stakes in line one.
- Story beats fact list: cut facts that need their own explanation (e.g. a 9% vs 8% lending-rate comparison).
- Both celebrating power and questioning a claim work ("vied, not richer" was the strongest line).

## Research errors caught in third-party explainers (ColdFusion "money printing" video)
- Fake Henry Ford and Abraham Lincoln money quotes.
- "Bank of Japan owns 80% of the stock market": really ~80% of Japanese ETFs, roughly 5-7% of market cap.
- QE "invented in 1989" (BoJ QE began 2001); $700bn TARP called QE.
- Fed Act "passed over the holiday": House 298-60 on 22 Dec 1913, Senate 43-25 on 23 Dec 1913.
- 10x money multiplier: the Bank of England (2014) calls it "not an accurate description".
- "Six men own a quarter of world wealth": no source.

## Tooling
- Wikimedia Commons API needs a descriptive User-Agent; read `extmetadata` for licence and artist.
- The Met's v1 search endpoint is retired; use `/public/collection/v1.1/search`.
- edge-tts intermittently fails; rerun until every `tts/*.json` exists; sanity-check total words.
- Speed-up to fit 2 minutes must also rescale captions.srt (done in assemble.py).
