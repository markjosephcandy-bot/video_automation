---
name: documentary-short-automation
description: Research, script, visualise, voice and render documentary-style finance / money-history videos (YouTube Shorts) with Gemini, Cloudflare Workers AI and ffmpeg. Load this to regain the full context of how EconoFables videos are made, or to make a new one.
---

# Documentary Short automation: the playbook

This file is the memory of the project. If you (human or AI agent) have lost context, read this first,
then `docs/STYLE_GUIDE.md`, `docs/LESSONS.md` and the worked example in `examples/money-promise-short/`.

## The channel
- **EconoFables** (`@EconoFables`): finance, banking, economy and money history, mainly for Indian viewers.
  Tagline: *Every rupee has a story.* Brand: navy `#14213D`, gold `#E9B44C`, cream `#F6EEDC`
  (fonts: Poppins, Montserrat, Playfair Display Italic, Bebas Neue, Courier Prime; all OFL, in `assets/fonts`).
- A Hindi Shorts channel uses the same pipeline with a Hindi voice (e.g. `hi-IN-MadhurNeural`) and Hindi text.
- Ending CTA (exact): **"Follow EconoFables. Every rupee has a story."** Change it in `brand.yaml` for another channel.

## Non-negotiable workflow (human in the loop)
1. **Research first.** Offer 3-6 *rare* topic options (`docvid topics`). No obvious stories. The human picks.
2. **Research brief + fact-check** (`docvid research`, `docvid factcheck`). Primary sources first.
3. **Script + visual plan** (`docvid script` -> `SCRIPT_REVIEW.md`). Show the script and planned images to the
   human. **Production starts only after they say go.**
4. **Build** (`docvid build`): voice -> timing -> visuals -> render -> captions -> final mp4 -> youtube.txt -> QA sheet.
5. **QA by eye**: open the contact sheet; check every frame (text clipping, captions over faces, empty bands,
   anachronisms in AI frames, dull/dark frames). Fix and re-render single beats (`docvid render ep 4 7`).
6. **Never publish** to YouTube or anywhere public without explicit approval. Upload privately for review.
7. After each upload, read retention (swiped-away %, average view) and log the lesson in `docs/LESSONS.md`.

## Shorts spec
Under 2 min (the assembler speeds up to fit `DOCVID_MAX_SECONDS`, default 119.5), 1080x1920, 30 fps, -14 LUFS,
captions burned in (1-3 words, Poppins 92 px, gold active word, y=1320), plus `captions.srt` for upload.

## Story rules
- Name the subject in the first one or two lines and state the stakes; lead with the subject's power.
  (A bare question opener + "That's the legend" made 59% swipe away.)
- One through-line: hook -> identity -> 2-3 escalating proofs -> turning point -> twist/fall -> payoff -> CTA.
- No question marks in titles, hooks or on-screen headings. No "myth-busting" openers.
- Full spoken sentences for TTS. Spoken numbers must match on-screen numbers.
- Attribute superlatives to their source. Where accounts conflict, say so on air or drop the figure.
- Precise words: "unauthorised" not "counterfeit" when the notes were genuine; "liable" not "punished".

## Visual rules (binding)
- Documentary style; every line gets a visual that shows what it says; cut every 2-4 s; never reuse an image to fill time.
- **Real images** where specific (named people, the actual document, the place, period art). Source tag on screen;
  licence + artist in the description. Wikimedia Commons (`docvid/commons.py`), The Met open access (CC0).
- **Typewriter scenes** for quoted documents: exact quote types on ruled white paper in time with the narration,
  big Courier type, the source name at the top, key phrase highlighted at the end; karaoke captions are muted there.
  (Replaced screenshot-plus-highlighter, which was unreadable on a phone.)
- **Animated infographics** for numbers: counter, donut, bars, line, timeline, ladder (Vox-style paper texture).
- **AI reconstructions** (Cloudflare Workers AI) only where nothing authentic exists. Bright, warm, period-accurate,
  labelled "Artist's impression" on screen, disclosed in the description. Check anachronisms (an 1834 London fire
  scene was first generated with Big Ben, which was built later; rejected).
- Images fill 9:16 with no empty bands (cover-crop, framed-on-blur, print-on-paper or horizontal pan).
- Headings small (Poppins 54 in a translucent navy bar at y=240) and never over a face; no heavy dark vignette.
- Prefer refined, brightened originals over dull grey scans.

## Pipeline map
| Step | Module | Output |
|---|---|---|
| topic options | `research.topics` (Gemini + Google Search grounding) | `TOPICS.md` |
| research brief | `research.brief` | `RESEARCH.md`, `sources.json` |
| fact-check | `research.verify` | `FACTCHECK.md` |
| script | `scriptgen.write` | `script.yaml`, `SCRIPT_REVIEW.md` |
| voice | `tts.run` (edge-tts, word timings) | `tts/NNN.mp3`, `tts/NNN.json` |
| timing | `timing.build` | `timeline.json` (beat durations, caption-mute ranges) |
| visuals | `visuals.build` -> `stills`, `anim`, `commons`, `cloudflare` | `images/*`, `credits.json` |
| render | `render.run` | `seg/NNN.mp4` |
| captions | `subs.run` | `caps.ass`, `captions.srt`, `transcript.txt` |
| final | `assemble.run` | `<Title> - EconoFables Short.mp4` |
| metadata | `publish.run` | `youtube.txt` |
| QA | `qa.run` | contact sheet + duration/LUFS report |

## script.yaml (the contract between steps)
```yaml
title: The Rich Get New Money First. Here's How It Works
format: short
protect: ["world inequality lab"]          # phrases captions must keep together
chapters:
- title: null
  beats:
  - say: Full spoken sentence(s).
    show: {type: heading, text: Money began as a promise, emphasis: [PROMISE]}   # or {type: cta}
    w: [0.62, 0.38]                          # optional slot weights when a beat has several visuals
    visuals:
    - {kind: real, query: "Code of Hammurabi stele Louvre", file: b02_1.png, fit: refine|framed|paper|pan, tag: "Code of Hammurabi, Louvre · CC BY 2.0"}
    - {kind: real, src: https://.../image.jpg, file: x.png, tag: "...", credit: "..."}
    - {kind: ai, prompt: "Babylonian scribe recording a grain loan on a clay tablet", what: "scribe records a loan", file: b02_0.png}
    - {kind: typewriter, header: Bank of England, sub: "Quarterly Bulletin, 2014 Q1", quote: "...", highlight: "...", file: b00.mp4}
    - {kind: counter|donut|bars|line|timeline|ladder, ..., file: b07.mp4}
```
Older episodes use `images: [file, ...]` instead of `visuals`; the renderer accepts both.

## Process lessons (short list; full list in docs/LESSONS.md)
- Verify in primary sources; check explainers claim by claim (dates, percentages, quotes go wrong most).
- edge-tts sometimes returns "No audio was received": `docvid tts` retries until every beat has timings.
- Auto-picked Commons images are a starting point: always eyeball `images/` before rendering.
- Subagents / helpers can claim success without writing files: check each output exists.
